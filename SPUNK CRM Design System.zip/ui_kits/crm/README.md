# SPUNK CRM — UI Kit

A high-fidelity, interactive React prototype of the SPUNK CRM dashboard. Built with bright/light theme, DM Sans typography, and purple accent (#7C6AF7).

## Screens

| Page | Description |
|------|-------------|
| Dashboard | Stat cards, revenue chart, orders-by-source donut, recent orders table, live activity feed |
| Orders | Filterable/searchable orders table, side-panel order detail drawer |
| Customers | Customer list with VIP/Regular/New filters, side-panel customer profile |
| DM Conversations | Two-pane chat UI — conversation list + live message thread with send |
| Products / Inventory / Analytics / Financials / Courier / Integrations / Settings | Placeholder stubs |

## Components

| File | Exports |
|------|---------|
| `Icons.jsx` | All Lucide-style icons as inline SVG React components via `window.Icons` |
| `Components.jsx` | `C.Button`, `C.Badge`, `C.StatCard`, `C.Card`, `C.PageWrapper`, `C.Avatar`, `C.channelColor` |
| `Sidebar.jsx` | `CRMSidebar` — full nav sidebar with collapse, active states, section labels |
| `Topbar.jsx` | `CRMTopbar` — search, notification bell with panel, avatar dropdown |
| `Dashboard.jsx` | `DashboardPage` — full dashboard with inline SVG charts |
| `Orders.jsx` | `OrdersPage` + `OrderDetail` slide-in panel |
| `Customers.jsx` | `CustomersPage` + `CustomerDetail` slide-in panel |
| `Conversations.jsx` | `ConversationsPage` — full chat prototype |
| `App.jsx` | `CRMApp` root + page router, mounts to `#root` |

## Design Tokens (Bright Theme)

```
--bg-base:       #F5F4FF   (page background)
--bg-surface:    #FFFFFF   (cards, sidebar)
--bg-elevated:   #FAFAFF   (table headers)
--bg-hover:      #F0EEFF   (row hover)
--border:        #E4E2F4
--text-primary:  #1A1828
--text-secondary:#6E6B85
--text-tertiary: #9C99B5
--accent:        #7C6AF7
--accent-muted:  #F0EEFF
--green:         #16A068
--amber:         #C97B0E
--red:           #C93A34
--blue:          #2970CE
```

## Usage

Open `index.html` directly in a browser or via a local server. All JSX is Babel-transpiled in-browser.

## Source

Recreated from: https://github.com/nomaanibrahim0336-ctrl/CRM- (branch: claude/nice-volta-6g81M)

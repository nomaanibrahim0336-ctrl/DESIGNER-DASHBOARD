// Shared UI components — BRIGHT/LIGHT theme
const { useState } = React;
const C = window.C = {};

// ── Light Theme Tokens ────────────────────────────────────────
C.T = {
  bgBase:       '#F5F4FF',   // page background (light purple tint)
  bgSurface:    '#FFFFFF',   // cards, sidebar
  bgElevated:   '#FAFAFF',   // table headers, code
  bgHover:      '#F0EEFF',   // hover rows
  border:       '#E4E2F4',
  borderSubtle: '#EDEDF6',
  textPrimary:  '#1A1828',
  textSecondary:'#6E6B85',
  textTertiary: '#9C99B5',
  accent:       '#7C6AF7',
  accentHover:  '#6B57F5',
  accentMuted:  '#F0EEFF',
  green:        '#16A068',  greenMuted: '#EDFAF4',
  amber:        '#C97B0E',  amberMuted: '#FFF8EB',
  red:          '#C93A34',  redMuted:   '#FFF1F0',
  blue:         '#2970CE',  blueMuted:  '#EBF4FF',
};

// ── Badge map (light) ─────────────────────────────────────────
const BM = {
  Delivered:      { bg:'#EDFAF4', color:'#16A068', border:'#16A06828' },
  Shipped:        { bg:'#EBF4FF', color:'#2970CE', border:'#2970CE28' },
  Processing:     { bg:'#F0EEFF', color:'#7C6AF7', border:'#7C6AF728' },
  Pending:        { bg:'#FFF8EB', color:'#C97B0E', border:'#C97B0E28' },
  Cancelled:      { bg:'#FFF1F0', color:'#C93A34', border:'#C93A3428' },
  'Low Stock':    { bg:'#FFF8EB', color:'#C97B0E', border:'#C97B0E28' },
  'Out of Stock': { bg:'#FFF1F0', color:'#C93A34', border:'#C93A3428' },
  Active:         { bg:'#EDFAF4', color:'#16A068', border:'#16A06828' },
  VIP:            { bg:'#F0EEFF', color:'#7C6AF7', border:'#7C6AF728' },
  Regular:        { bg:'#F5F4FF', color:'#6E6B85', border:'#E4E2F4'  },
  New:            { bg:'#EBF4FF', color:'#2970CE', border:'#2970CE28' },
  Open:           { bg:'#EDFAF4', color:'#16A068', border:'#16A06828' },
  Closed:         { bg:'#F5F4FF', color:'#6E6B85', border:'#E4E2F4'  },
  Connected:      { bg:'#EDFAF4', color:'#16A068', border:'#16A06828' },
  Disconnected:   { bg:'#FFF1F0', color:'#C93A34', border:'#C93A3428' },
};

// ── Button ───────────────────────────────────────────────────
C.Button = ({ children, variant='primary', size='md', onClick, disabled=false, style={} }) => {
  const [hov, setHov] = useState(false);
  const pad = { sm:'5px 12px', md:'8px 16px', lg:'10px 20px' };
  const fs  = { sm:'12px', md:'13px', lg:'14px' };
  const v = {
    primary:   { background: hov?'#6B57F5':'#7C6AF7', color:'#fff', border:'none' },
    secondary: { background: hov?'#F5F4FF':'transparent', color:'#1A1828', border:'1px solid #E4E2F4' },
    ghost:     { background: hov?'#F0EEFF':'transparent', color: hov?'#7C6AF7':'#6E6B85', border:'none' },
    danger:    { background: hov?'#FFE5E4':'#FFF1F0', color:'#C93A34', border:'1px solid #C93A3428' },
    success:   { background: hov?'#D8F7EC':'#EDFAF4', color:'#16A068', border:'1px solid #16A06828' },
  };
  return (
    <button onClick={onClick} disabled={disabled}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{ display:'inline-flex', alignItems:'center', gap:'6px', borderRadius:'8px',
        fontWeight:500, fontFamily:"'DM Sans',sans-serif", cursor:disabled?'not-allowed':'pointer',
        transition:'all 0.15s', outline:'none', padding:pad[size], fontSize:fs[size],
        opacity:disabled?0.5:1, boxShadow: variant==='primary'&&!hov?'0 1px 3px rgba(124,106,247,0.3)':'none',
        ...v[variant], ...style }}>
      {children}
    </button>
  );
};

// ── Badge ─────────────────────────────────────────────────────
C.Badge = ({ status }) => {
  const s = BM[status] || { bg:'#F5F4FF', color:'#6E6B85', border:'#E4E2F4' };
  return (
    <span style={{ display:'inline-flex', alignItems:'center', padding:'2px 10px',
      borderRadius:'999px', fontSize:'11px', fontWeight:600, letterSpacing:'0.02em',
      background:s.bg, color:s.color, border:`1px solid ${s.border}`, whiteSpace:'nowrap' }}>
      {status}
    </span>
  );
};

// ── StatCard ──────────────────────────────────────────────────
C.StatCard = ({ title, value, change, changeType='positive', icon: Icon, iconColor='#7C6AF7' }) => {
  const { TrendingUp, TrendingDown } = window.Icons;
  const isPos = changeType === 'positive';
  return (
    <div style={{ background:'#fff', border:'1px solid #E4E2F4', borderRadius:'12px',
      padding:'20px', display:'flex', flexDirection:'column', gap:'12px',
      boxShadow:'0 1px 4px rgba(28,24,60,0.06)' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
        <span style={{ color:'#6E6B85', fontSize:'13px', fontWeight:500 }}>{title}</span>
        {Icon && (
          <div style={{ width:'36px', height:'36px', borderRadius:'8px',
            background:iconColor+'18', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <Icon size={18} color={iconColor} />
          </div>
        )}
      </div>
      <div style={{ display:'flex', alignItems:'flex-end', gap:'10px' }}>
        <span style={{ fontSize:'26px', fontWeight:700, color:'#1A1828', lineHeight:1 }}>{value}</span>
        {change && (
          <div style={{ display:'flex', alignItems:'center', gap:'3px',
            color:isPos?'#16A068':'#C93A34', fontSize:'12px', fontWeight:500, paddingBottom:'2px' }}>
            {isPos ? <TrendingUp size={13}/> : <TrendingDown size={13}/>}
            {change}
          </div>
        )}
      </div>
    </div>
  );
};

// ── Card ──────────────────────────────────────────────────────
C.Card = ({ children, style={}, noPad=false }) => (
  <div style={{ background:'#fff', border:'1px solid #E4E2F4', borderRadius:'12px',
    padding:noPad?0:'20px', boxShadow:'0 1px 4px rgba(28,24,60,0.06)', ...style }}>
    {children}
  </div>
);

// ── PageWrapper ───────────────────────────────────────────────
C.PageWrapper = ({ title, subtitle, actions, children }) => (
  <div style={{ padding:'28px', height:'100%', overflowY:'auto' }}>
    {(title||actions) && (
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:'24px' }}>
        <div>
          {title && <h1 style={{ fontSize:'20px', fontWeight:700, color:'#1A1828', margin:0 }}>{title}</h1>}
          {subtitle && <p style={{ fontSize:'13px', color:'#6E6B85', margin:'4px 0 0' }}>{subtitle}</p>}
        </div>
        {actions && <div style={{ display:'flex', gap:'8px' }}>{actions}</div>}
      </div>
    )}
    {children}
  </div>
);

// ── Avatar ────────────────────────────────────────────────────
C.Avatar = ({ initials, size=34, gradient=false, color='#7C6AF7' }) => (
  <div style={{ width:size, height:size, borderRadius:'50%',
    background: gradient ? 'linear-gradient(135deg,#7C6AF7,#4FACFE)' : color+'18',
    border: gradient ? 'none' : `1.5px solid ${color}28`,
    display:'flex', alignItems:'center', justifyContent:'center',
    fontSize: size>28 ? '13px' : '10px', fontWeight:700,
    color: gradient ? '#fff' : color, flexShrink:0 }}>
    {initials}
  </div>
);

C.channelColor = { WhatsApp:'#25D366', Instagram:'#E1306C', Telegram:'#2CA5E0', Email:'#2970CE', TikTok:'#1A1828', Twitter:'#1DA1F2', Messenger:'#006AFF', LiveChat:'#7C6AF7' };

Object.assign(window, { C });

// App root — SPUNK CRM bright theme
const { useState } = React;
const { Icons } = window;

// Placeholder page for unbuilt sections
function PlaceholderPage({ title }) {
  return (
    <div style={{ padding:'28px', height:'100%', overflowY:'auto' }}>
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:'24px' }}>
        <h1 style={{ fontSize:'20px', fontWeight:700, color:'#1A1828', margin:0 }}>{title}</h1>
      </div>
      <div style={{ background:'#fff', border:'1px solid #E4E2F4', borderRadius:'12px', padding:'60px 40px',
        display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
        textAlign:'center', gap:'12px', boxShadow:'0 1px 4px rgba(28,24,60,0.06)' }}>
        <div style={{ width:'52px', height:'52px', borderRadius:'14px', background:'#F0EEFF',
          border:'1px solid #7C6AF728', display:'flex', alignItems:'center', justifyContent:'center' }}>
          <Icons.Layers size={24} color="#7C6AF7"/>
        </div>
        <div style={{ fontSize:'15px', fontWeight:600, color:'#1A1828' }}>{title}</div>
        <div style={{ fontSize:'13px', color:'#9C99B5', maxWidth:'320px' }}>
          This section is part of the SPUNK CRM design system UI kit. Full recreation coming soon.
        </div>
      </div>
    </div>
  );
}

function App() {
  const [page, setPage] = useState('dashboard');

  const renderPage = () => {
    switch (page) {
      case 'dashboard':     return <window.DashboardPage/>;
      case 'orders':        return <window.OrdersPage/>;
      case 'customers':     return <window.CustomersPage/>;
      case 'conversations': return <window.ConversationsPage/>;
      case 'products':      return <PlaceholderPage title="Products"/>;
      case 'inventory':     return <PlaceholderPage title="Inventory"/>;
      case 'analytics':     return <PlaceholderPage title="Analytics"/>;
      case 'financials':    return <PlaceholderPage title="Financials"/>;
      case 'courier':       return <PlaceholderPage title="Courier"/>;
      case 'integrations':  return <PlaceholderPage title="Integrations"/>;
      case 'settings':      return <PlaceholderPage title="Settings"/>;
      default:              return <window.DashboardPage/>;
    }
  };

  return (
    <div style={{ display:'flex', height:'100vh', background:'#F5F4FF', fontFamily:"'DM Sans', sans-serif",
      fontSize:'13px', WebkitFontSmoothing:'antialiased' }}>
      {/* Sidebar */}
      <window.CRMSidebar currentPage={page} setPage={setPage}/>

      {/* Main area */}
      <div style={{ flex:1, display:'flex', flexDirection:'column', minWidth:0, overflow:'hidden' }}>
        <window.CRMTopbar currentPage={page}/>
        <div style={{ flex:1, overflow:'hidden' }}>
          {renderPage()}
        </div>
      </div>
    </div>
  );
}

window.CRMApp = App;

// Mount
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);

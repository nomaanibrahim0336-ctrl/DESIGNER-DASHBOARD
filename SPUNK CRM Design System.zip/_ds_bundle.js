/* @ds-bundle: {"format":3,"namespace":"SPUNKCRMDesignSystem_019e04","components":[],"sourceHashes":{"ui_kits/crm/App.jsx":"0581450845fe","ui_kits/crm/Components.jsx":"096a831fcad2","ui_kits/crm/Conversations.jsx":"ab9f954cd638","ui_kits/crm/Customers.jsx":"c74efa961500","ui_kits/crm/Dashboard.jsx":"f5b6627f2431","ui_kits/crm/Icons.jsx":"99678ceb1409","ui_kits/crm/Orders.jsx":"36abd70e9828","ui_kits/crm/Sidebar.jsx":"e3d9d3f6a1bb","ui_kits/crm/Topbar.jsx":"3dea9146c3d1","ui_kits/crm/data.js":"7a8c57dbb315"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SPUNKCRMDesignSystem_019e04 = window.SPUNKCRMDesignSystem_019e04 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/crm/App.jsx
try { (() => {
// App root — SPUNK CRM bright theme
const {
  useState
} = React;
const {
  Icons
} = window;

// Placeholder page for unbuilt sections
function PlaceholderPage({
  title
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '28px',
      height: '100%',
      overflowY: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      marginBottom: '24px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: '20px',
      fontWeight: 700,
      color: '#1A1828',
      margin: 0
    }
  }, title)), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1px solid #E4E2F4',
      borderRadius: '12px',
      padding: '60px 40px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      gap: '12px',
      boxShadow: '0 1px 4px rgba(28,24,60,0.06)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '52px',
      height: '52px',
      borderRadius: '14px',
      background: '#F0EEFF',
      border: '1px solid #7C6AF728',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icons.Layers, {
    size: 24,
    color: "#7C6AF7"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '15px',
      fontWeight: 600,
      color: '#1A1828'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '13px',
      color: '#9C99B5',
      maxWidth: '320px'
    }
  }, "This section is part of the SPUNK CRM design system UI kit. Full recreation coming soon.")));
}
function App() {
  const [page, setPage] = useState('dashboard');
  const renderPage = () => {
    switch (page) {
      case 'dashboard':
        return /*#__PURE__*/React.createElement(window.DashboardPage, null);
      case 'orders':
        return /*#__PURE__*/React.createElement(window.OrdersPage, null);
      case 'customers':
        return /*#__PURE__*/React.createElement(window.CustomersPage, null);
      case 'conversations':
        return /*#__PURE__*/React.createElement(window.ConversationsPage, null);
      case 'products':
        return /*#__PURE__*/React.createElement(PlaceholderPage, {
          title: "Products"
        });
      case 'inventory':
        return /*#__PURE__*/React.createElement(PlaceholderPage, {
          title: "Inventory"
        });
      case 'analytics':
        return /*#__PURE__*/React.createElement(PlaceholderPage, {
          title: "Analytics"
        });
      case 'financials':
        return /*#__PURE__*/React.createElement(PlaceholderPage, {
          title: "Financials"
        });
      case 'courier':
        return /*#__PURE__*/React.createElement(PlaceholderPage, {
          title: "Courier"
        });
      case 'integrations':
        return /*#__PURE__*/React.createElement(PlaceholderPage, {
          title: "Integrations"
        });
      case 'settings':
        return /*#__PURE__*/React.createElement(PlaceholderPage, {
          title: "Settings"
        });
      default:
        return /*#__PURE__*/React.createElement(window.DashboardPage, null);
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100vh',
      background: '#F5F4FF',
      fontFamily: "'DM Sans', sans-serif",
      fontSize: '13px',
      WebkitFontSmoothing: 'antialiased'
    }
  }, /*#__PURE__*/React.createElement(window.CRMSidebar, {
    currentPage: page,
    setPage: setPage
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(window.CRMTopbar, {
    currentPage: page
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'hidden'
    }
  }, renderPage())));
}
window.CRMApp = App;

// Mount
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/crm/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/crm/Components.jsx
try { (() => {
// Shared UI components — BRIGHT/LIGHT theme
const {
  useState
} = React;
const C = window.C = {};

// ── Light Theme Tokens ────────────────────────────────────────
C.T = {
  bgBase: '#F5F4FF',
  // page background (light purple tint)
  bgSurface: '#FFFFFF',
  // cards, sidebar
  bgElevated: '#FAFAFF',
  // table headers, code
  bgHover: '#F0EEFF',
  // hover rows
  border: '#E4E2F4',
  borderSubtle: '#EDEDF6',
  textPrimary: '#1A1828',
  textSecondary: '#6E6B85',
  textTertiary: '#9C99B5',
  accent: '#7C6AF7',
  accentHover: '#6B57F5',
  accentMuted: '#F0EEFF',
  green: '#16A068',
  greenMuted: '#EDFAF4',
  amber: '#C97B0E',
  amberMuted: '#FFF8EB',
  red: '#C93A34',
  redMuted: '#FFF1F0',
  blue: '#2970CE',
  blueMuted: '#EBF4FF'
};

// ── Badge map (light) ─────────────────────────────────────────
const BM = {
  Delivered: {
    bg: '#EDFAF4',
    color: '#16A068',
    border: '#16A06828'
  },
  Shipped: {
    bg: '#EBF4FF',
    color: '#2970CE',
    border: '#2970CE28'
  },
  Processing: {
    bg: '#F0EEFF',
    color: '#7C6AF7',
    border: '#7C6AF728'
  },
  Pending: {
    bg: '#FFF8EB',
    color: '#C97B0E',
    border: '#C97B0E28'
  },
  Cancelled: {
    bg: '#FFF1F0',
    color: '#C93A34',
    border: '#C93A3428'
  },
  'Low Stock': {
    bg: '#FFF8EB',
    color: '#C97B0E',
    border: '#C97B0E28'
  },
  'Out of Stock': {
    bg: '#FFF1F0',
    color: '#C93A34',
    border: '#C93A3428'
  },
  Active: {
    bg: '#EDFAF4',
    color: '#16A068',
    border: '#16A06828'
  },
  VIP: {
    bg: '#F0EEFF',
    color: '#7C6AF7',
    border: '#7C6AF728'
  },
  Regular: {
    bg: '#F5F4FF',
    color: '#6E6B85',
    border: '#E4E2F4'
  },
  New: {
    bg: '#EBF4FF',
    color: '#2970CE',
    border: '#2970CE28'
  },
  Open: {
    bg: '#EDFAF4',
    color: '#16A068',
    border: '#16A06828'
  },
  Closed: {
    bg: '#F5F4FF',
    color: '#6E6B85',
    border: '#E4E2F4'
  },
  Connected: {
    bg: '#EDFAF4',
    color: '#16A068',
    border: '#16A06828'
  },
  Disconnected: {
    bg: '#FFF1F0',
    color: '#C93A34',
    border: '#C93A3428'
  }
};

// ── Button ───────────────────────────────────────────────────
C.Button = ({
  children,
  variant = 'primary',
  size = 'md',
  onClick,
  disabled = false,
  style = {}
}) => {
  const [hov, setHov] = useState(false);
  const pad = {
    sm: '5px 12px',
    md: '8px 16px',
    lg: '10px 20px'
  };
  const fs = {
    sm: '12px',
    md: '13px',
    lg: '14px'
  };
  const v = {
    primary: {
      background: hov ? '#6B57F5' : '#7C6AF7',
      color: '#fff',
      border: 'none'
    },
    secondary: {
      background: hov ? '#F5F4FF' : 'transparent',
      color: '#1A1828',
      border: '1px solid #E4E2F4'
    },
    ghost: {
      background: hov ? '#F0EEFF' : 'transparent',
      color: hov ? '#7C6AF7' : '#6E6B85',
      border: 'none'
    },
    danger: {
      background: hov ? '#FFE5E4' : '#FFF1F0',
      color: '#C93A34',
      border: '1px solid #C93A3428'
    },
    success: {
      background: hov ? '#D8F7EC' : '#EDFAF4',
      color: '#16A068',
      border: '1px solid #16A06828'
    }
  };
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    disabled: disabled,
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      borderRadius: '8px',
      fontWeight: 500,
      fontFamily: "'DM Sans',sans-serif",
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'all 0.15s',
      outline: 'none',
      padding: pad[size],
      fontSize: fs[size],
      opacity: disabled ? 0.5 : 1,
      boxShadow: variant === 'primary' && !hov ? '0 1px 3px rgba(124,106,247,0.3)' : 'none',
      ...v[variant],
      ...style
    }
  }, children);
};

// ── Badge ─────────────────────────────────────────────────────
C.Badge = ({
  status
}) => {
  const s = BM[status] || {
    bg: '#F5F4FF',
    color: '#6E6B85',
    border: '#E4E2F4'
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '2px 10px',
      borderRadius: '999px',
      fontSize: '11px',
      fontWeight: 600,
      letterSpacing: '0.02em',
      background: s.bg,
      color: s.color,
      border: `1px solid ${s.border}`,
      whiteSpace: 'nowrap'
    }
  }, status);
};

// ── StatCard ──────────────────────────────────────────────────
C.StatCard = ({
  title,
  value,
  change,
  changeType = 'positive',
  icon: Icon,
  iconColor = '#7C6AF7'
}) => {
  const {
    TrendingUp,
    TrendingDown
  } = window.Icons;
  const isPos = changeType === 'positive';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1px solid #E4E2F4',
      borderRadius: '12px',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      gap: '12px',
      boxShadow: '0 1px 4px rgba(28,24,60,0.06)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#6E6B85',
      fontSize: '13px',
      fontWeight: 500
    }
  }, title), Icon && /*#__PURE__*/React.createElement("div", {
    style: {
      width: '36px',
      height: '36px',
      borderRadius: '8px',
      background: iconColor + '18',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    size: 18,
    color: iconColor
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: '10px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '26px',
      fontWeight: 700,
      color: '#1A1828',
      lineHeight: 1
    }
  }, value), change && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '3px',
      color: isPos ? '#16A068' : '#C93A34',
      fontSize: '12px',
      fontWeight: 500,
      paddingBottom: '2px'
    }
  }, isPos ? /*#__PURE__*/React.createElement(TrendingUp, {
    size: 13
  }) : /*#__PURE__*/React.createElement(TrendingDown, {
    size: 13
  }), change)));
};

// ── Card ──────────────────────────────────────────────────────
C.Card = ({
  children,
  style = {},
  noPad = false
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    background: '#fff',
    border: '1px solid #E4E2F4',
    borderRadius: '12px',
    padding: noPad ? 0 : '20px',
    boxShadow: '0 1px 4px rgba(28,24,60,0.06)',
    ...style
  }
}, children);

// ── PageWrapper ───────────────────────────────────────────────
C.PageWrapper = ({
  title,
  subtitle,
  actions,
  children
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '28px',
    height: '100%',
    overflowY: 'auto'
  }
}, (title || actions) && /*#__PURE__*/React.createElement("div", {
  style: {
    display: 'flex',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: '24px'
  }
}, /*#__PURE__*/React.createElement("div", null, title && /*#__PURE__*/React.createElement("h1", {
  style: {
    fontSize: '20px',
    fontWeight: 700,
    color: '#1A1828',
    margin: 0
  }
}, title), subtitle && /*#__PURE__*/React.createElement("p", {
  style: {
    fontSize: '13px',
    color: '#6E6B85',
    margin: '4px 0 0'
  }
}, subtitle)), actions && /*#__PURE__*/React.createElement("div", {
  style: {
    display: 'flex',
    gap: '8px'
  }
}, actions)), children);

// ── Avatar ────────────────────────────────────────────────────
C.Avatar = ({
  initials,
  size = 34,
  gradient = false,
  color = '#7C6AF7'
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    width: size,
    height: size,
    borderRadius: '50%',
    background: gradient ? 'linear-gradient(135deg,#7C6AF7,#4FACFE)' : color + '18',
    border: gradient ? 'none' : `1.5px solid ${color}28`,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: size > 28 ? '13px' : '10px',
    fontWeight: 700,
    color: gradient ? '#fff' : color,
    flexShrink: 0
  }
}, initials);
C.channelColor = {
  WhatsApp: '#25D366',
  Instagram: '#E1306C',
  Telegram: '#2CA5E0',
  Email: '#2970CE',
  TikTok: '#1A1828',
  Twitter: '#1DA1F2',
  Messenger: '#006AFF',
  LiveChat: '#7C6AF7'
};
Object.assign(window, {
  C
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/crm/Components.jsx", error: String((e && e.message) || e) }); }

// ui_kits/crm/Conversations.jsx
try { (() => {
// DM Conversations page — SPUNK CRM bright theme
const {
  useState,
  useRef,
  useEffect
} = React;
const {
  C,
  Icons
} = window;
function Conversations() {
  const {
    conversations
  } = window.CRM_DATA;
  const [active, setActive] = useState(conversations[0]);
  const [input, setInput] = useState('');
  const [msgs, setMsgs] = useState(() => {
    const m = {};
    conversations.forEach(c => {
      m[c.id] = c.messages;
    });
    return m;
  });
  const [filter, setFilter] = useState('All');
  const bottomRef = useRef(null);
  const filtered = filter === 'All' ? conversations : conversations.filter(c => c.status === filter);
  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.parentElement.scrollTop = bottomRef.current.parentElement.scrollHeight;
    }
  }, [active, msgs]);
  const sendMessage = () => {
    if (!input.trim()) return;
    const newMsg = {
      from: 'agent',
      text: input.trim(),
      time: 'Just now'
    };
    setMsgs(prev => ({
      ...prev,
      [active.id]: [...(prev[active.id] || []), newMsg]
    }));
    setInput('');
  };
  const chColor = C.channelColor;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100%',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '320px',
      flexShrink: 0,
      borderRight: '1px solid #E4E2F4',
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 16px 12px',
      borderBottom: '1px solid #EDEDF6'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '16px',
      fontWeight: 700,
      color: '#1A1828',
      marginBottom: '10px'
    }
  }, "DM Conversations"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Icons.Search, {
    size: 13,
    color: "#9C99B5",
    style: {
      position: 'absolute',
      left: '10px',
      top: '50%',
      transform: 'translateY(-50%)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Search conversations\u2026",
    style: {
      width: '100%',
      paddingLeft: '30px',
      padding: '7px 12px 7px 30px',
      background: '#F5F4FF',
      border: '1px solid #E4E2F4',
      borderRadius: '8px',
      fontSize: '13px',
      color: '#1A1828',
      outline: 'none',
      fontFamily: "'DM Sans',sans-serif"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '4px',
      marginTop: '10px'
    }
  }, ['All', 'Open', 'Closed'].map(f => /*#__PURE__*/React.createElement("button", {
    key: f,
    onClick: () => setFilter(f),
    style: {
      padding: '5px 12px',
      borderRadius: '6px',
      fontSize: '12px',
      fontWeight: 500,
      border: 'none',
      cursor: 'pointer',
      fontFamily: "'DM Sans',sans-serif",
      background: filter === f ? '#7C6AF7' : 'transparent',
      color: filter === f ? '#fff' : '#6E6B85'
    }
  }, f)))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto'
    }
  }, filtered.map(conv => {
    const isActive = active?.id === conv.id;
    const channelColor = chColor[conv.channel] || '#7C6AF7';
    return /*#__PURE__*/React.createElement("div", {
      key: conv.id,
      onClick: () => setActive(conv),
      style: {
        padding: '13px 16px',
        borderBottom: '1px solid #EDEDF6',
        cursor: 'pointer',
        background: isActive ? '#F0EEFF' : 'transparent',
        borderLeft: isActive ? '3px solid #7C6AF7' : '3px solid transparent',
        transition: 'all 0.1s'
      },
      onMouseEnter: e => {
        if (!isActive) e.currentTarget.style.background = '#F5F4FF';
      },
      onMouseLeave: e => {
        if (!isActive) e.currentTarget.style.background = 'transparent';
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '10px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement(C.Avatar, {
      initials: conv.avatar,
      size: 38
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        bottom: -2,
        right: -2,
        width: '14px',
        height: '14px',
        borderRadius: '50%',
        background: channelColor,
        border: '2px solid #fff',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: '7px',
        color: '#fff',
        fontWeight: 700
      }
    }, conv.channel === 'WhatsApp' ? 'W' : conv.channel === 'Instagram' ? 'I' : conv.channel[0]))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '3px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: '13px',
        fontWeight: 600,
        color: '#1A1828'
      }
    }, conv.customer), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: '11px',
        color: '#9C99B5'
      }
    }, conv.time)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: '12px',
        color: '#6E6B85',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        maxWidth: '160px'
      }
    }, conv.lastMsg), conv.unread > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        minWidth: '18px',
        height: '18px',
        borderRadius: '9px',
        background: '#7C6AF7',
        color: '#fff',
        fontSize: '10px',
        fontWeight: 700,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 4px'
      }
    }, conv.unread)))));
  }))), active ? /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      background: '#FAFAFF'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 20px',
      background: '#fff',
      borderBottom: '1px solid #EDEDF6',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement(C.Avatar, {
    initials: active.avatar,
    size: 38
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '14px',
      fontWeight: 600,
      color: '#1A1828'
    }
  }, active.customer), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '6px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '7px',
      height: '7px',
      borderRadius: '50%',
      background: '#16A068'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '12px',
      color: '#9C99B5'
    }
  }, "via ", active.channel)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '8px'
    }
  }, /*#__PURE__*/React.createElement(C.Badge, {
    status: active.status
  }), /*#__PURE__*/React.createElement(C.Button, {
    variant: "ghost",
    size: "sm"
  }, /*#__PURE__*/React.createElement(Icons.UserIcon, {
    size: 13
  }), "Profile"))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    }
  }, (msgs[active.id] || []).map((msg, i) => {
    const isAgent = msg.from === 'agent';
    const isBot = msg.from === 'bot';
    const isCustomer = msg.from === 'customer';
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        justifyContent: isCustomer ? 'flex-start' : 'flex-end',
        gap: '8px',
        alignItems: 'flex-end'
      }
    }, isCustomer && /*#__PURE__*/React.createElement(C.Avatar, {
      initials: active.avatar,
      size: 28
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: '70%'
      }
    }, (isBot || isAgent) && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: '10px',
        color: '#9C99B5',
        marginBottom: '3px',
        textAlign: 'right'
      }
    }, isBot ? '🤖 Bot' : 'Agent'), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '10px 14px',
        borderRadius: isCustomer ? '12px 12px 12px 4px' : '12px 12px 4px 12px',
        background: isCustomer ? '#fff' : isBot ? '#F0EEFF' : '#7C6AF7',
        color: isCustomer ? '#1A1828' : isBot ? '#7C6AF7' : '#fff',
        border: isCustomer ? '1px solid #E4E2F4' : isBot ? '1px solid #7C6AF728' : 'none',
        fontSize: '13px',
        lineHeight: 1.5,
        boxShadow: '0 1px 2px rgba(28,24,60,0.06)'
      }
    }, msg.text), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: '11px',
        color: '#9C99B5',
        marginTop: '3px',
        textAlign: isCustomer ? 'left' : 'right'
      }
    }, msg.time)));
  }), /*#__PURE__*/React.createElement("div", {
    ref: bottomRef
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 20px',
      background: '#fff',
      borderTop: '1px solid #EDEDF6',
      display: 'flex',
      gap: '10px',
      alignItems: 'flex-end',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("textarea", {
    value: input,
    onChange: e => setInput(e.target.value),
    onKeyDown: e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    },
    placeholder: "Type a message\u2026 (Enter to send)",
    rows: 2,
    style: {
      flex: 1,
      background: '#F5F4FF',
      border: '1px solid #E4E2F4',
      borderRadius: '10px',
      padding: '10px 14px',
      fontSize: '13px',
      color: '#1A1828',
      outline: 'none',
      resize: 'none',
      fontFamily: "'DM Sans',sans-serif",
      lineHeight: 1.5
    }
  }), /*#__PURE__*/React.createElement(C.Button, {
    variant: "primary",
    onClick: sendMessage,
    style: {
      height: '40px',
      paddingLeft: '14px',
      paddingRight: '14px'
    }
  }, /*#__PURE__*/React.createElement(Icons.Send, {
    size: 14
  })))) : /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#9C99B5'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icons.MessageSquare, {
    size: 40,
    color: "#E4E2F4"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: '12px',
      fontSize: '14px'
    }
  }, "Select a conversation"))));
}
window.ConversationsPage = Conversations;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/crm/Conversations.jsx", error: String((e && e.message) || e) }); }

// ui_kits/crm/Customers.jsx
try { (() => {
// Customers page — SPUNK CRM bright theme
const {
  useState,
  useMemo
} = React;
const {
  C,
  Icons
} = window;
const STATUS_FILTERS = ['All', 'VIP', 'Regular', 'New'];
function Customers() {
  const {
    customers
  } = window.CRM_DATA;
  const [statusFilter, setStatusFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const filtered = useMemo(() => customers.filter(c => {
    const q = search.toLowerCase();
    const matchSearch = !q || c.name.toLowerCase().includes(q) || c.city.toLowerCase().includes(q) || c.phone.includes(q);
    const matchStatus = statusFilter === 'All' || c.status === statusFilter;
    return matchSearch && matchStatus;
  }), [search, statusFilter]);
  return /*#__PURE__*/React.createElement(C.PageWrapper, {
    title: "Customers",
    subtitle: `${customers.length} total customers`,
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(C.Button, {
      variant: "secondary",
      size: "sm"
    }, /*#__PURE__*/React.createElement(Icons.Download, {
      size: 13
    }), "Export"), /*#__PURE__*/React.createElement(C.Button, {
      variant: "primary",
      size: "sm"
    }, /*#__PURE__*/React.createElement(Icons.UserPlus, {
      size: 13
    }), "Add Customer"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: '16px',
      marginBottom: '24px'
    }
  }, [{
    label: 'VIP Customers',
    val: customers.filter(c => c.status === 'VIP').length,
    color: '#7C6AF7',
    icon: Icons.Users
  }, {
    label: 'Regular',
    val: customers.filter(c => c.status === 'Regular').length,
    color: '#2970CE',
    icon: Icons.Users
  }, {
    label: 'New This Month',
    val: customers.filter(c => c.status === 'New').length,
    color: '#16A068',
    icon: Icons.UserPlus
  }].map(s => /*#__PURE__*/React.createElement("div", {
    key: s.label,
    style: {
      background: '#fff',
      border: '1px solid #E4E2F4',
      borderRadius: '12px',
      padding: '16px 20px',
      display: 'flex',
      alignItems: 'center',
      gap: '14px',
      boxShadow: '0 1px 4px rgba(28,24,60,0.06)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '40px',
      height: '40px',
      borderRadius: '10px',
      background: s.color + '14',
      border: `1px solid ${s.color}28`,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(s.icon, {
    size: 18,
    color: s.color
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '22px',
      fontWeight: 700,
      color: '#1A1828',
      lineHeight: 1
    }
  }, s.val), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '12px',
      color: '#9C99B5',
      marginTop: '3px'
    }
  }, s.label))))), /*#__PURE__*/React.createElement(C.Card, {
    noPad: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 20px',
      borderBottom: '1px solid #EDEDF6',
      display: 'flex',
      alignItems: 'center',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: 1,
      maxWidth: '300px'
    }
  }, /*#__PURE__*/React.createElement(Icons.Search, {
    size: 13,
    color: "#9C99B5",
    style: {
      position: 'absolute',
      left: '10px',
      top: '50%',
      transform: 'translateY(-50%)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    value: search,
    onChange: e => setSearch(e.target.value),
    placeholder: "Search customers\u2026",
    style: {
      width: '100%',
      paddingLeft: '30px',
      paddingRight: '12px',
      paddingTop: '7px',
      paddingBottom: '7px',
      background: '#F5F4FF',
      border: '1px solid #E4E2F4',
      borderRadius: '8px',
      fontSize: '13px',
      color: '#1A1828',
      outline: 'none',
      fontFamily: "'DM Sans',sans-serif"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '4px',
      background: '#F5F4FF',
      padding: '4px',
      borderRadius: '8px',
      border: '1px solid #E4E2F4'
    }
  }, STATUS_FILTERS.map(s => /*#__PURE__*/React.createElement("button", {
    key: s,
    onClick: () => setStatusFilter(s),
    style: {
      padding: '5px 12px',
      borderRadius: '6px',
      fontSize: '12px',
      fontWeight: 500,
      border: 'none',
      cursor: 'pointer',
      fontFamily: "'DM Sans',sans-serif",
      background: statusFilter === s ? '#7C6AF7' : 'transparent',
      color: statusFilter === s ? '#fff' : '#6E6B85'
    }
  }, s)))), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: '#FAFAFF'
    }
  }, ['CUSTOMER', 'PHONE', 'CITY', 'ORDERS', 'TOTAL SPENT', 'LAST ORDER', 'STATUS'].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      padding: '9px 16px',
      textAlign: 'left',
      fontSize: '10px',
      fontWeight: 700,
      color: '#9C99B5',
      letterSpacing: '0.06em',
      borderBottom: '1px solid #EDEDF6',
      whiteSpace: 'nowrap'
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, filtered.map(c => /*#__PURE__*/React.createElement("tr", {
    key: c.id,
    onClick: () => setSelected(c),
    style: {
      borderBottom: '1px solid #EDEDF6',
      cursor: 'pointer',
      transition: 'background 0.1s'
    },
    onMouseEnter: e => e.currentTarget.style.background = '#F5F4FF',
    onMouseLeave: e => e.currentTarget.style.background = 'transparent'
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px'
    }
  }, /*#__PURE__*/React.createElement(C.Avatar, {
    initials: c.avatar,
    size: 32,
    gradient: c.status === 'VIP'
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '13px',
      fontWeight: 500,
      color: '#1A1828'
    }
  }, c.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '11px',
      color: '#9C99B5'
    }
  }, c.source)))), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px',
      fontSize: '12px',
      color: '#6E6B85',
      fontFamily: 'monospace'
    }
  }, c.phone), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px',
      fontSize: '13px',
      color: '#6E6B85'
    }
  }, c.city), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px',
      fontSize: '13px',
      color: '#1A1828',
      fontWeight: 600
    }
  }, c.orders), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px',
      fontSize: '13px',
      color: '#1A1828',
      fontWeight: 600
    }
  }, "PKR ", c.spent.toLocaleString()), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px',
      fontSize: '12px',
      color: '#9C99B5',
      fontFamily: 'monospace'
    }
  }, c.lastOrder), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px'
    }
  }, /*#__PURE__*/React.createElement(C.Badge, {
    status: c.status
  }))))))), selected && /*#__PURE__*/React.createElement(CustomerDetail, {
    customer: selected,
    onClose: () => setSelected(null)
  }));
}
function CustomerDetail({
  customer: c,
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(26,24,40,0.4)',
      zIndex: 200,
      display: 'flex',
      justifyContent: 'flex-end'
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '400px',
      height: '100%',
      background: '#fff',
      boxShadow: '-4px 0 24px rgba(28,24,60,0.12)',
      overflowY: 'auto'
    },
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px',
      borderBottom: '1px solid #EDEDF6',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: '14px',
      color: '#1A1828'
    }
  }, "Customer Profile"), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      background: '#F5F4FF',
      border: '1px solid #E4E2F4',
      borderRadius: '6px',
      width: '28px',
      height: '28px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      color: '#9C99B5'
    }
  }, /*#__PURE__*/React.createElement(Icons.X, {
    size: 14
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px',
      display: 'flex',
      flexDirection: 'column',
      gap: '20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '12px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(C.Avatar, {
    initials: c.avatar,
    size: 60,
    gradient: c.status === 'VIP'
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '18px',
      fontWeight: 700,
      color: '#1A1828'
    }
  }, c.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '13px',
      color: '#9C99B5',
      marginTop: '4px'
    }
  }, c.city, " \xB7 ", c.source)), /*#__PURE__*/React.createElement(C.Badge, {
    status: c.status
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '12px'
    }
  }, [{
    label: 'Orders',
    val: c.orders
  }, {
    label: 'Total Spent',
    val: `PKR ${c.spent.toLocaleString()}`
  }, {
    label: 'Avg Order',
    val: `PKR ${Math.round(c.spent / c.orders).toLocaleString()}`
  }, {
    label: 'Last Order',
    val: c.lastOrder
  }].map(s => /*#__PURE__*/React.createElement("div", {
    key: s.label,
    style: {
      background: '#F5F4FF',
      border: '1px solid #E4E2F4',
      borderRadius: '10px',
      padding: '14px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '16px',
      fontWeight: 700,
      color: '#1A1828'
    }
  }, s.val), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '11px',
      color: '#9C99B5',
      marginTop: '4px'
    }
  }, s.label)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '10px',
      fontWeight: 700,
      color: '#9C99B5',
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      marginBottom: '10px'
    }
  }, "CONTACT"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#F5F4FF',
      border: '1px solid #E4E2F4',
      borderRadius: '10px',
      padding: '14px',
      display: 'flex',
      alignItems: 'center',
      gap: '10px'
    }
  }, /*#__PURE__*/React.createElement(Icons.UserIcon, {
    size: 14,
    color: "#9C99B5"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'monospace',
      fontSize: '13px',
      color: '#1A1828'
    }
  }, c.phone))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '8px'
    }
  }, /*#__PURE__*/React.createElement(C.Button, {
    variant: "primary",
    style: {
      flex: 1,
      justifyContent: 'center'
    }
  }, "View Orders"), /*#__PURE__*/React.createElement(C.Button, {
    variant: "secondary",
    style: {
      flex: 1,
      justifyContent: 'center'
    }
  }, "Send Message")))));
}
window.CustomersPage = Customers;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/crm/Customers.jsx", error: String((e && e.message) || e) }); }

// ui_kits/crm/Dashboard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Dashboard page — SPUNK CRM bright theme
const {
  useState
} = React;
const {
  C,
  Icons
} = window;

// Mini sparkline SVG from data array
function Sparkline({
  data,
  color = '#7C6AF7',
  width = 120,
  height = 36
}) {
  if (!data || data.length < 2) return null;
  const vals = data.map(d => d.v);
  const min = Math.min(...vals),
    max = Math.max(...vals);
  const range = max - min || 1;
  const pts = vals.map((v, i) => {
    const x = i / (vals.length - 1) * width;
    const y = height - (v - min) / range * (height - 4) - 2;
    return `${x},${y}`;
  }).join(' ');
  const area = `M0,${height} L${pts.split(' ').map(p => p).join(' L')} L${width},${height} Z`;
  return /*#__PURE__*/React.createElement("svg", {
    width: width,
    height: height,
    style: {
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: `sg-${color.replace('#', '')}`,
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: color,
    stopOpacity: "0.15"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: color,
    stopOpacity: "0"
  }))), /*#__PURE__*/React.createElement("path", {
    d: area,
    fill: `url(#sg-${color.replace('#', '')})`
  }), /*#__PURE__*/React.createElement("polyline", {
    points: pts,
    fill: "none",
    stroke: color,
    strokeWidth: "2",
    strokeLinejoin: "round",
    strokeLinecap: "round"
  }));
}

// Donut chart for order source
function DonutChart({
  data,
  size = 110
}) {
  const total = data.reduce((a, d) => a + d.value, 0);
  let cum = 0;
  const cx = size / 2,
    cy = size / 2,
    r = size * 0.38,
    inner = size * 0.24;
  const slices = data.map(d => {
    const pct = d.value / total;
    const startAngle = cum * 2 * Math.PI - Math.PI / 2;
    cum += pct;
    const endAngle = cum * 2 * Math.PI - Math.PI / 2;
    const x1 = cx + r * Math.cos(startAngle),
      y1 = cy + r * Math.sin(startAngle);
    const x2 = cx + r * Math.cos(endAngle),
      y2 = cy + r * Math.sin(endAngle);
    const xi1 = cx + inner * Math.cos(startAngle),
      yi1 = cy + inner * Math.sin(startAngle);
    const xi2 = cx + inner * Math.cos(endAngle),
      yi2 = cy + inner * Math.sin(endAngle);
    const large = pct > 0.5 ? 1 : 0;
    return {
      ...d,
      path: `M${x1},${y1} A${r},${r} 0 ${large} 1 ${x2},${y2} L${xi2},${yi2} A${inner},${inner} 0 ${large} 0 ${xi1},${yi1} Z`
    };
  });
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size
  }, slices.map((s, i) => /*#__PURE__*/React.createElement("path", {
    key: i,
    d: s.path,
    fill: s.color,
    stroke: "#fff",
    strokeWidth: "2"
  })), /*#__PURE__*/React.createElement("text", {
    x: cx,
    y: cy,
    textAnchor: "middle",
    dominantBaseline: "middle",
    fontSize: "13",
    fontWeight: "700",
    fill: "#1A1828"
  }, total, "%"));
}
function Dashboard() {
  const {
    revenueData,
    orders,
    ordersBySource,
    activityFeed
  } = window.CRM_DATA;
  const stats = [{
    title: 'Total Orders',
    value: '1,284',
    change: '+12%',
    changeType: 'positive',
    icon: Icons.ShoppingCart,
    iconColor: '#7C6AF7'
  }, {
    title: 'Revenue',
    value: 'PKR 842K',
    change: '+8.2%',
    changeType: 'positive',
    icon: Icons.DollarSign,
    iconColor: '#16A068'
  }, {
    title: 'Customers',
    value: '3,410',
    change: '+5.1%',
    changeType: 'positive',
    icon: Icons.Users,
    iconColor: '#2970CE'
  }, {
    title: 'Pending',
    value: '47',
    change: null,
    icon: Icons.Clock,
    iconColor: '#C97B0E'
  }];
  const typeIcons = {
    order: Icons.ShoppingBag,
    message: Icons.MessageSquare,
    customer: Icons.Users,
    payment: Icons.CreditCard
  };
  return /*#__PURE__*/React.createElement(C.PageWrapper, {
    title: "Dashboard",
    subtitle: "Welcome back, here's what's happening today",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(C.Button, {
      variant: "secondary",
      size: "sm"
    }, /*#__PURE__*/React.createElement(Icons.Download, {
      size: 13
    }), "Export"), /*#__PURE__*/React.createElement(C.Button, {
      variant: "primary",
      size: "sm"
    }, /*#__PURE__*/React.createElement(Icons.RefreshCw, {
      size: 13
    }), "Sync"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: '16px',
      marginBottom: '24px'
    }
  }, stats.map(s => /*#__PURE__*/React.createElement(C.StatCard, _extends({
    key: s.title
  }, s)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 340px',
      gap: '16px',
      marginBottom: '24px'
    }
  }, /*#__PURE__*/React.createElement(C.Card, {
    noPad: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 20px 12px',
      borderBottom: '1px solid #EDEDF6',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: '14px',
      color: '#1A1828'
    }
  }, "Revenue \u2014 Last 30 Days"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '12px',
      color: '#9C99B5'
    }
  }, "Nov 5 \u2013 Dec 4, 2024")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: '12px',
      marginBottom: '16px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '28px',
      fontWeight: 700,
      color: '#1A1828',
      lineHeight: 1
    }
  }, "PKR 842K"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '13px',
      color: '#16A068',
      fontWeight: 600,
      paddingBottom: '3px',
      display: 'flex',
      alignItems: 'center',
      gap: '3px'
    }
  }, /*#__PURE__*/React.createElement(Icons.TrendingUp, {
    size: 13
  }), " +8.2% vs last month")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: '130px'
    }
  }, /*#__PURE__*/React.createElement(RevenueChart, {
    data: revenueData
  })))), /*#__PURE__*/React.createElement(C.Card, {
    noPad: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 20px 12px',
      borderBottom: '1px solid #EDEDF6'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: '14px',
      color: '#1A1828'
    }
  }, "Orders by Source")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 20px',
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(DonutChart, {
    data: ordersBySource
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '7px'
    }
  }, ordersBySource.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.name,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '8px',
      height: '8px',
      borderRadius: '50%',
      background: s.color,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '12px',
      color: '#6E6B85',
      flex: 1
    }
  }, s.name), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: '4px',
      background: '#F0EEFF',
      borderRadius: '2px',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${s.value}%`,
      height: '100%',
      background: s.color,
      borderRadius: '2px'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '12px',
      fontWeight: 600,
      color: '#1A1828',
      minWidth: '28px',
      textAlign: 'right'
    }
  }, s.value, "%"))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 300px',
      gap: '16px'
    }
  }, /*#__PURE__*/React.createElement(C.Card, {
    noPad: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 20px',
      borderBottom: '1px solid #EDEDF6',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: '14px',
      color: '#1A1828'
    }
  }, "Recent Orders"), /*#__PURE__*/React.createElement(C.Button, {
    variant: "ghost",
    size: "sm"
  }, "View all")), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: '#FAFAFF'
    }
  }, ['ORDER ID', 'CUSTOMER', 'AMOUNT', 'STATUS', 'DATE'].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      padding: '9px 16px',
      textAlign: 'left',
      fontSize: '10px',
      fontWeight: 700,
      color: '#9C99B5',
      letterSpacing: '0.06em',
      borderBottom: '1px solid #EDEDF6'
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, orders.slice(0, 6).map(o => /*#__PURE__*/React.createElement("tr", {
    key: o.id,
    style: {
      borderBottom: '1px solid #EDEDF6',
      transition: 'background 0.1s'
    },
    onMouseEnter: e => e.currentTarget.style.background = '#F5F4FF',
    onMouseLeave: e => e.currentTarget.style.background = 'transparent'
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'monospace',
      fontSize: '12px',
      color: '#7C6AF7',
      fontWeight: 500
    }
  }, o.id)), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    }
  }, /*#__PURE__*/React.createElement(C.Avatar, {
    initials: o.avatar,
    size: 26
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '13px',
      color: '#1A1828'
    }
  }, o.customer))), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px',
      fontSize: '13px',
      color: '#1A1828',
      fontWeight: 500
    }
  }, "PKR ", o.amount.toLocaleString()), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px'
    }
  }, /*#__PURE__*/React.createElement(C.Badge, {
    status: o.status
  })), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px',
      fontSize: '12px',
      color: '#9C99B5'
    }
  }, o.date)))))), /*#__PURE__*/React.createElement(C.Card, {
    noPad: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 20px',
      borderBottom: '1px solid #EDEDF6'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: '14px',
      color: '#1A1828'
    }
  }, "Live Activity")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 0'
    }
  }, activityFeed.map(item => {
    const Icon = typeIcons[item.type] || Icons.Bell;
    return /*#__PURE__*/React.createElement("div", {
      key: item.id,
      style: {
        display: 'flex',
        alignItems: 'flex-start',
        gap: '10px',
        padding: '10px 16px',
        transition: 'background 0.1s',
        cursor: 'default'
      },
      onMouseEnter: e => e.currentTarget.style.background = '#F5F4FF',
      onMouseLeave: e => e.currentTarget.style.background = 'transparent'
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: '30px',
        height: '30px',
        borderRadius: '8px',
        flexShrink: 0,
        background: item.color + '14',
        border: `1px solid ${item.color}22`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      size: 14,
      color: item.color
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: '12px',
        color: '#1A1828',
        lineHeight: 1.4
      }
    }, item.text), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: '11px',
        color: '#9C99B5',
        marginTop: '2px'
      }
    }, item.time)));
  })))));
}

// Inline revenue area chart
function RevenueChart({
  data
}) {
  const W = 560,
    H = 110;
  const vals = data.map(d => d.v);
  const min = Math.min(...vals),
    max = Math.max(...vals);
  const range = max - min || 1;
  const pts = vals.map((v, i) => {
    const x = i / (vals.length - 1) * W;
    const y = H - (v - min) / range * (H - 8) - 4;
    return [x, y];
  });
  const linePts = pts.map(p => p.join(',')).join(' ');
  const area = `M0,${H} ${pts.map(p => `L${p[0]},${p[1]}`).join(' ')} L${W},${H} Z`;
  // x-axis labels — every 5th
  const labels = data.filter((_, i) => i % 5 === 0).map((d, li) => {
    const idx = li * 5;
    const x = idx / (data.length - 1) * W;
    return {
      x,
      label: d.date
    };
  });
  return /*#__PURE__*/React.createElement("svg", {
    width: "100%",
    height: "130",
    viewBox: `0 0 ${W} ${H + 20}`,
    preserveAspectRatio: "none",
    style: {
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "revGrad",
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: "#7C6AF7",
    stopOpacity: "0.18"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: "#7C6AF7",
    stopOpacity: "0"
  }))), /*#__PURE__*/React.createElement("path", {
    d: area,
    fill: "url(#revGrad)"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: linePts,
    fill: "none",
    stroke: "#7C6AF7",
    strokeWidth: "2.5",
    strokeLinejoin: "round",
    strokeLinecap: "round"
  }), labels.map((l, i) => /*#__PURE__*/React.createElement("text", {
    key: i,
    x: l.x,
    y: H + 16,
    textAnchor: "middle",
    fontSize: "9",
    fill: "#9C99B5"
  }, l.label)));
}
window.DashboardPage = Dashboard;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/crm/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/crm/Icons.jsx
try { (() => {
// Inline Lucide-style SVG icon components for CRM UI Kit
// All icons: stroke, fill=none, strokeWidth=2, round caps/joins

const {
  React
} = window;
const ico = inner => ({
  size = 16,
  color = 'currentColor',
  style = {}
}) => React.createElement('svg', {
  width: size,
  height: size,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: color,
  strokeWidth: 2,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
  style: {
    flexShrink: 0,
    display: 'block',
    ...style
  },
  dangerouslySetInnerHTML: {
    __html: inner
  }
});
const LayoutDashboard = ico('<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>');
const ShoppingCart = ico('<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>');
const Users = ico('<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>');
const MessageSquare = ico('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>');
const Package = ico('<path d="M16.5 9.4 7.5 4.21"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>');
const Layers = ico('<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>');
const BarChart2 = ico('<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>');
const DollarSign = ico('<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>');
const Truck = ico('<rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>');
const Zap = ico('<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>');
const Settings = ico('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>');
const ChevronLeft = ico('<polyline points="15 18 9 12 15 6"/>');
const ChevronRight = ico('<polyline points="9 18 15 12 9 6"/>');
const ChevronDown = ico('<polyline points="6 9 12 15 18 9"/>');
const Search = ico('<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>');
const Bell = ico('<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>');
const TrendingUp = ico('<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>');
const TrendingDown = ico('<polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/>');
const Clock = ico('<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>');
const X = ico('<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>');
const Plus = ico('<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>');
const LogOut = ico('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>');
const UserIcon = ico('<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>');
const HelpCircle = ico('<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>');
const Store = ico('<path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/><path d="M22 7v3a2 2 0 0 1-2 2a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 16 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 12 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 8 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 4 12a2 2 0 0 1-2-2V7"/>');
const ShoppingBag = ico('<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>');
const AlertCircle = ico('<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>');
const CreditCard = ico('<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>');
const RefreshCw = ico('<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>');
const Filter = ico('<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>');
const Download = ico('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>');
const Keyboard = ico('<rect x="2" y="4" width="20" height="16" rx="2" ry="2"/><path d="M6 8h.001M10 8h.001M14 8h.001M18 8h.001M8 12h.001M12 12h.001M16 12h.001M7 16h10"/>');
const UserPlus = ico('<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/>');
const Send = ico('<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>');
Object.assign(window, {
  Icons: {
    LayoutDashboard,
    ShoppingCart,
    Users,
    MessageSquare,
    Package,
    Layers,
    BarChart2,
    DollarSign,
    Truck,
    Zap,
    Settings,
    ChevronLeft,
    ChevronRight,
    ChevronDown,
    Search,
    Bell,
    TrendingUp,
    TrendingDown,
    Clock,
    X,
    Plus,
    LogOut,
    UserIcon,
    HelpCircle,
    Store,
    ShoppingBag,
    AlertCircle,
    CreditCard,
    RefreshCw,
    Filter,
    Download,
    Keyboard,
    UserPlus,
    Send
  }
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/crm/Icons.jsx", error: String((e && e.message) || e) }); }

// ui_kits/crm/Orders.jsx
try { (() => {
// Orders page — SPUNK CRM bright theme
const {
  useState,
  useMemo
} = React;
const {
  C,
  Icons
} = window;
const STATUS_FILTERS = ['All', 'Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
const COURIER_MAP = {
  TCS: '#FF6B00',
  Leopard: '#005A9E',
  BlueEx: '#0066CC',
  PostEx: '#E82127'
};
function Orders() {
  const {
    orders
  } = window.CRM_DATA;
  const [status, setStatus] = useState('All');
  const [search, setSearch] = useState('');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const filtered = useMemo(() => {
    return orders.filter(o => {
      const matchStatus = status === 'All' || o.status === status;
      const q = search.toLowerCase();
      const matchSearch = !q || o.id.toLowerCase().includes(q) || o.customer.toLowerCase().includes(q) || o.city.toLowerCase().includes(q);
      return matchStatus && matchSearch;
    });
  }, [status, search]);
  return /*#__PURE__*/React.createElement(C.PageWrapper, {
    title: "Orders",
    subtitle: `${orders.length} total orders`,
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(C.Button, {
      variant: "secondary",
      size: "sm"
    }, /*#__PURE__*/React.createElement(Icons.Filter, {
      size: 13
    }), "Filter"), /*#__PURE__*/React.createElement(C.Button, {
      variant: "secondary",
      size: "sm"
    }, /*#__PURE__*/React.createElement(Icons.Download, {
      size: 13
    }), "Export CSV"), /*#__PURE__*/React.createElement(C.Button, {
      variant: "primary",
      size: "sm"
    }, /*#__PURE__*/React.createElement(Icons.Plus, {
      size: 13
    }), "New Order"))
  }, /*#__PURE__*/React.createElement(C.Card, {
    noPad: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 20px',
      borderBottom: '1px solid #EDEDF6',
      display: 'flex',
      alignItems: 'center',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: 1,
      maxWidth: '340px'
    }
  }, /*#__PURE__*/React.createElement(Icons.Search, {
    size: 13,
    color: "#9C99B5",
    style: {
      position: 'absolute',
      left: '10px',
      top: '50%',
      transform: 'translateY(-50%)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    value: search,
    onChange: e => setSearch(e.target.value),
    placeholder: "Search by ID, customer, city\u2026",
    style: {
      width: '100%',
      paddingLeft: '30px',
      paddingRight: '12px',
      paddingTop: '7px',
      paddingBottom: '7px',
      background: '#F5F4FF',
      border: '1px solid #E4E2F4',
      borderRadius: '8px',
      fontSize: '13px',
      color: '#1A1828',
      outline: 'none',
      fontFamily: "'DM Sans',sans-serif"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '4px',
      background: '#F5F4FF',
      padding: '4px',
      borderRadius: '8px',
      border: '1px solid #E4E2F4'
    }
  }, STATUS_FILTERS.map(s => /*#__PURE__*/React.createElement("button", {
    key: s,
    onClick: () => setStatus(s),
    style: {
      padding: '5px 12px',
      borderRadius: '6px',
      fontSize: '12px',
      fontWeight: 500,
      border: 'none',
      cursor: 'pointer',
      fontFamily: "'DM Sans',sans-serif",
      transition: 'all 0.1s',
      background: status === s ? '#7C6AF7' : 'transparent',
      color: status === s ? '#fff' : '#6E6B85'
    }
  }, s)))), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: '#FAFAFF'
    }
  }, ['ORDER ID', 'CUSTOMER', 'CITY', 'AMOUNT', 'PAYMENT', 'COURIER', 'STATUS', 'DATE'].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      padding: '9px 16px',
      textAlign: 'left',
      fontSize: '10px',
      fontWeight: 700,
      color: '#9C99B5',
      letterSpacing: '0.06em',
      borderBottom: '1px solid #EDEDF6',
      whiteSpace: 'nowrap'
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, filtered.map(o => /*#__PURE__*/React.createElement("tr", {
    key: o.id,
    onClick: () => setSelectedOrder(o),
    style: {
      borderBottom: '1px solid #EDEDF6',
      cursor: 'pointer',
      transition: 'background 0.1s'
    },
    onMouseEnter: e => e.currentTarget.style.background = '#F5F4FF',
    onMouseLeave: e => e.currentTarget.style.background = 'transparent'
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'monospace',
      fontSize: '12px',
      color: '#7C6AF7',
      fontWeight: 500
    }
  }, o.id)), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    }
  }, /*#__PURE__*/React.createElement(C.Avatar, {
    initials: o.avatar,
    size: 26
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '13px',
      color: '#1A1828'
    }
  }, o.customer))), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px',
      fontSize: '13px',
      color: '#6E6B85'
    }
  }, o.city), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px',
      fontSize: '13px',
      color: '#1A1828',
      fontWeight: 600
    }
  }, "PKR ", o.amount.toLocaleString()), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px',
      fontSize: '12px',
      color: '#6E6B85'
    }
  }, o.payment), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px'
    }
  }, o.courier ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '12px',
      fontWeight: 600,
      color: COURIER_MAP[o.courier] || '#6E6B85'
    }
  }, o.courier) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '12px',
      color: '#9C99B5'
    }
  }, "\u2014")), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px'
    }
  }, /*#__PURE__*/React.createElement(C.Badge, {
    status: o.status
  })), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '10px 16px',
      fontSize: '12px',
      color: '#9C99B5',
      fontFamily: 'monospace'
    }
  }, o.date))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 20px',
      borderTop: '1px solid #EDEDF6',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '12px',
      color: '#9C99B5'
    }
  }, "Showing ", filtered.length, " of ", orders.length, " orders"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '4px'
    }
  }, [1, 2, 3, '…', 128].map((p, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    style: {
      width: '32px',
      height: '32px',
      borderRadius: '6px',
      fontSize: '12px',
      fontWeight: 500,
      border: '1px solid',
      cursor: 'pointer',
      fontFamily: "'DM Sans',sans-serif",
      background: p === 1 ? '#7C6AF7' : 'transparent',
      color: p === 1 ? '#fff' : '#6E6B85',
      borderColor: p === 1 ? '#7C6AF7' : '#E4E2F4'
    }
  }, p))))), selectedOrder && /*#__PURE__*/React.createElement(OrderDetail, {
    order: selectedOrder,
    onClose: () => setSelectedOrder(null)
  }));
}
function OrderDetail({
  order,
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(26,24,40,0.4)',
      zIndex: 200,
      display: 'flex',
      justifyContent: 'flex-end'
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '420px',
      height: '100%',
      background: '#fff',
      boxShadow: '-4px 0 24px rgba(28,24,60,0.12)',
      display: 'flex',
      flexDirection: 'column',
      overflowY: 'auto'
    },
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px',
      borderBottom: '1px solid #EDEDF6',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'monospace',
      fontSize: '13px',
      color: '#7C6AF7',
      fontWeight: 600
    }
  }, order.id), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '12px',
      color: '#9C99B5',
      marginTop: '2px'
    }
  }, order.date)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '8px',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(C.Badge, {
    status: order.status
  }), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      background: '#F5F4FF',
      border: '1px solid #E4E2F4',
      borderRadius: '6px',
      width: '28px',
      height: '28px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      color: '#9C99B5'
    }
  }, /*#__PURE__*/React.createElement(Icons.X, {
    size: 14
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      gap: '20px'
    }
  }, /*#__PURE__*/React.createElement(Section, {
    title: "Customer"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement(C.Avatar, {
    initials: order.avatar,
    size: 42,
    gradient: true
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '14px',
      fontWeight: 600,
      color: '#1A1828'
    }
  }, order.customer), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '12px',
      color: '#9C99B5'
    }
  }, order.city)))), /*#__PURE__*/React.createElement(Section, {
    title: "Order Details"
  }, /*#__PURE__*/React.createElement(DetailRow, {
    label: "Amount",
    value: `PKR ${order.amount.toLocaleString()}`
  }), /*#__PURE__*/React.createElement(DetailRow, {
    label: "Payment",
    value: order.payment
  }), /*#__PURE__*/React.createElement(DetailRow, {
    label: "Source",
    value: order.source
  }), /*#__PURE__*/React.createElement(DetailRow, {
    label: "City",
    value: order.city
  })), order.courier && /*#__PURE__*/React.createElement(Section, {
    title: "Shipping"
  }, /*#__PURE__*/React.createElement(DetailRow, {
    label: "Courier",
    value: order.courier,
    valueColor: COURIER_MAP[order.courier]
  }), /*#__PURE__*/React.createElement(DetailRow, {
    label: "Tracking",
    value: order.tracking,
    mono: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '8px',
      paddingTop: '4px'
    }
  }, /*#__PURE__*/React.createElement(C.Button, {
    variant: "primary",
    style: {
      flex: 1,
      justifyContent: 'center'
    }
  }, "Update Status"), /*#__PURE__*/React.createElement(C.Button, {
    variant: "secondary",
    style: {
      flex: 1,
      justifyContent: 'center'
    }
  }, "Print Label")))));
}
function Section({
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '10px',
      fontWeight: 700,
      color: '#9C99B5',
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      marginBottom: '10px'
    }
  }, title), children);
}
function DetailRow({
  label,
  value,
  valueColor,
  mono
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '6px 0',
      borderBottom: '1px solid #EDEDF6'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '12px',
      color: '#9C99B5'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '13px',
      fontWeight: 500,
      color: valueColor || '#1A1828',
      fontFamily: mono ? 'monospace' : 'inherit'
    }
  }, value));
}
window.OrdersPage = Orders;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/crm/Orders.jsx", error: String((e && e.message) || e) }); }

// ui_kits/crm/Sidebar.jsx
try { (() => {
// Sidebar — SPUNK CRM (bright theme)
const {
  useState
} = React;
const {
  Icons
} = window;
const navGroups = [{
  label: 'OVERVIEW',
  items: [{
    label: 'Dashboard',
    icon: 'LayoutDashboard',
    page: 'dashboard'
  }]
}, {
  label: 'SALES',
  items: [{
    label: 'Orders',
    icon: 'ShoppingCart',
    page: 'orders'
  }, {
    label: 'Customers',
    icon: 'Users',
    page: 'customers'
  }, {
    label: 'DM Conversations',
    icon: 'MessageSquare',
    page: 'conversations'
  }]
}, {
  label: 'CATALOG',
  items: [{
    label: 'Products',
    icon: 'Package',
    page: 'products'
  }, {
    label: 'Inventory',
    icon: 'Layers',
    page: 'inventory'
  }]
}, {
  label: 'PERFORMANCE',
  items: [{
    label: 'Analytics',
    icon: 'BarChart2',
    page: 'analytics'
  }, {
    label: 'Financials',
    icon: 'DollarSign',
    page: 'financials'
  }]
}, {
  label: 'LOGISTICS',
  items: [{
    label: 'Courier',
    icon: 'Truck',
    page: 'courier'
  }]
}, {
  label: 'INTEGRATIONS',
  items: [{
    label: 'Integrations',
    icon: 'Zap',
    page: 'integrations'
  }]
}, {
  label: 'SETTINGS',
  items: [{
    label: 'Settings',
    icon: 'Settings',
    page: 'settings'
  }]
}];
function Sidebar({
  currentPage,
  setPage
}) {
  const [collapsed, setCollapsed] = useState(false);
  const w = collapsed ? '64px' : '240px';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: w,
      minWidth: w,
      height: '100%',
      background: '#fff',
      borderRight: '1px solid #E4E2F4',
      display: 'flex',
      flexDirection: 'column',
      transition: 'width 0.2s ease, min-width 0.2s ease',
      overflow: 'hidden',
      boxShadow: '1px 0 0 #E4E2F4'
    }
  }, !collapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 16px 12px',
      borderBottom: '1px solid #EDEDF6'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '28px',
      height: '28px',
      background: 'linear-gradient(135deg,#7C6AF7,#9180FF)',
      borderRadius: '7px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '12px',
      fontWeight: 800,
      color: '#fff',
      flexShrink: 0
    }
  }, "C"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      fontSize: '15px',
      color: '#1A1828'
    }
  }, "CRM"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '10px',
      fontWeight: 600,
      padding: '2px 6px',
      background: '#F0EEFF',
      color: '#7C6AF7',
      borderRadius: '4px',
      border: '1px solid #7C6AF728'
    }
  }, "PRO"))), collapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      height: '56px',
      borderBottom: '1px solid #EDEDF6',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '28px',
      height: '28px',
      background: 'linear-gradient(135deg,#7C6AF7,#9180FF)',
      borderRadius: '7px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '12px',
      fontWeight: 800,
      color: '#fff'
    }
  }, "C")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      overflowX: 'hidden',
      padding: '8px 0'
    }
  }, navGroups.map(group => /*#__PURE__*/React.createElement("div", {
    key: group.label,
    style: {
      marginBottom: '4px'
    }
  }, !collapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 16px 4px',
      fontSize: '10px',
      fontWeight: 700,
      color: '#9C99B5',
      letterSpacing: '0.08em',
      whiteSpace: 'nowrap'
    }
  }, group.label), collapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      height: '6px'
    }
  }), group.items.map(item => {
    const active = currentPage === item.page;
    const Icon = Icons[item.icon];
    return /*#__PURE__*/React.createElement(NavItem, {
      key: item.page,
      label: item.label,
      icon: Icon,
      active: active,
      collapsed: collapsed,
      onClick: () => setPage(item.page)
    });
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid #EDEDF6',
      padding: '10px',
      display: 'flex',
      justifyContent: collapsed ? 'center' : 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setCollapsed(!collapsed),
    style: {
      background: '#F5F4FF',
      border: '1px solid #E4E2F4',
      borderRadius: '6px',
      width: '28px',
      height: '28px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      color: '#9C99B5',
      transition: 'all 0.15s'
    }
  }, collapsed ? /*#__PURE__*/React.createElement(Icons.ChevronRight, {
    size: 14
  }) : /*#__PURE__*/React.createElement(Icons.ChevronLeft, {
    size: 14
  }))));
}
function NavItem({
  label,
  icon: Icon,
  active,
  collapsed,
  onClick
}) {
  const [hov, setHov] = useState(false);
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      padding: collapsed ? '10px' : '8px 14px',
      justifyContent: collapsed ? 'center' : 'flex-start',
      width: '100%',
      background: active ? '#F0EEFF' : hov ? '#F5F4FF' : 'transparent',
      borderLeft: active ? '3px solid #7C6AF7' : '3px solid transparent',
      borderRight: 'none',
      borderTop: 'none',
      borderBottom: 'none',
      borderRadius: collapsed ? '8px' : '0',
      margin: collapsed ? '2px 8px' : '0',
      cursor: 'pointer',
      color: active ? '#7C6AF7' : hov ? '#1A1828' : '#6E6B85',
      fontSize: '13px',
      fontWeight: active ? 600 : 400,
      transition: 'all 0.1s',
      fontFamily: "'DM Sans',sans-serif",
      whiteSpace: 'nowrap',
      outline: 'none',
      width: collapsed ? 'calc(100% - 16px)' : '100%'
    }
  }, Icon && /*#__PURE__*/React.createElement(Icon, {
    size: 16
  }), !collapsed && /*#__PURE__*/React.createElement("span", null, label));
}
window.CRMSidebar = Sidebar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/crm/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/crm/Topbar.jsx
try { (() => {
// Topbar — SPUNK CRM (bright theme)
const {
  useState,
  useRef,
  useEffect
} = React;
const {
  Icons
} = window;
const notifications = [{
  id: 1,
  icon: 'ShoppingBag',
  text: 'New order #ORD-7841 from Aisha Malik',
  time: '2 min ago',
  unread: true,
  color: '#7C6AF7'
}, {
  id: 2,
  icon: 'MessageSquare',
  text: 'Sara Khan sent a message on Instagram',
  time: '8 min ago',
  unread: true,
  color: '#E1306C'
}, {
  id: 3,
  icon: 'Truck',
  text: 'Order #ORD-7840 shipped via Leopard',
  time: '22 min ago',
  unread: true,
  color: '#C97B0E'
}, {
  id: 4,
  icon: 'AlertCircle',
  text: 'Low stock alert: Samsung Galaxy Buds (7 left)',
  time: '45 min ago',
  unread: true,
  color: '#C93A34'
}, {
  id: 5,
  icon: 'CreditCard',
  text: 'Payment received PKR 19,800',
  time: '1 hr ago',
  unread: false,
  color: '#16A068'
}, {
  id: 6,
  icon: 'MessageSquare',
  text: 'Zainab Hussain asking about bulk pricing',
  time: '2 hr ago',
  unread: false,
  color: '#2970CE'
}];
function Topbar({
  currentPage
}) {
  const [notifOpen, setNotifOpen] = useState(false);
  const [avatarOpen, setAvatarOpen] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const [notifs, setNotifs] = useState(notifications);
  const notifRef = useRef(null);
  const avatarRef = useRef(null);
  const unread = notifs.filter(n => n.unread).length;
  useEffect(() => {
    const handler = e => {
      if (notifRef.current && !notifRef.current.contains(e.target)) setNotifOpen(false);
      if (avatarRef.current && !avatarRef.current.contains(e.target)) setAvatarOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);
  const pageTitle = {
    dashboard: 'Dashboard',
    orders: 'Orders',
    customers: 'Customers',
    conversations: 'DM Conversations',
    products: 'Products',
    inventory: 'Inventory',
    analytics: 'Analytics',
    financials: 'Financials',
    courier: 'Courier',
    integrations: 'Integrations',
    settings: 'Settings'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '60px',
      background: '#fff',
      borderBottom: '1px solid #E4E2F4',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 24px',
      flexShrink: 0,
      zIndex: 100,
      boxShadow: '0 1px 3px rgba(28,24,60,0.06)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: '160px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '16px',
      fontWeight: 700,
      color: '#1A1828'
    }
  }, pageTitle[currentPage] || 'Dashboard')), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      maxWidth: '420px',
      margin: '0 24px',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Icons.Search, {
    size: 14,
    color: "#9C99B5",
    style: {
      position: 'absolute',
      left: '12px',
      top: '50%',
      transform: 'translateY(-50%)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Search orders, customers\u2026",
    readOnly: true,
    style: {
      width: '100%',
      background: searchFocused ? '#fff' : '#F5F4FF',
      border: `1px solid ${searchFocused ? '#7C6AF7' : '#E4E2F4'}`,
      borderRadius: '8px',
      padding: '7px 52px 7px 34px',
      color: '#1A1828',
      fontSize: '13px',
      outline: 'none',
      fontFamily: "'DM Sans',sans-serif",
      transition: 'all 0.15s',
      cursor: 'pointer',
      boxShadow: searchFocused ? '0 0 0 3px #7C6AF718' : 'none'
    },
    onFocus: () => setSearchFocused(true),
    onBlur: () => setSearchFocused(false)
  }), /*#__PURE__*/React.createElement("kbd", {
    style: {
      position: 'absolute',
      right: '10px',
      top: '50%',
      transform: 'translateY(-50%)',
      background: '#F0EEFF',
      border: '1px solid #E4E2F4',
      borderRadius: '4px',
      padding: '1px 5px',
      fontSize: '11px',
      color: '#7C6AF7',
      fontFamily: 'monospace'
    }
  }, "\u2318K")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      minWidth: '160px',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    ref: notifRef,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      setNotifOpen(!notifOpen);
      setAvatarOpen(false);
    },
    style: {
      background: notifOpen ? '#F0EEFF' : '#F5F4FF',
      border: '1px solid #E4E2F4',
      borderRadius: '8px',
      width: '36px',
      height: '36px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      color: '#6E6B85',
      transition: 'all 0.15s',
      outline: 'none'
    }
  }, /*#__PURE__*/React.createElement(Icons.Bell, {
    size: 16,
    color: notifOpen ? '#7C6AF7' : '#6E6B85'
  })), unread > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '-4px',
      right: '-4px',
      width: '16px',
      height: '16px',
      borderRadius: '50%',
      background: '#C93A34',
      color: '#fff',
      fontSize: '10px',
      fontWeight: 700,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: '2px solid #fff'
    }
  }, unread), notifOpen && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'calc(100% + 8px)',
      right: 0,
      width: '360px',
      background: '#fff',
      border: '1px solid #E4E2F4',
      borderRadius: '12px',
      boxShadow: '0 8px 32px rgba(28,24,60,0.12)',
      zIndex: 300
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 16px',
      borderBottom: '1px solid #EDEDF6',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      color: '#1A1828',
      fontSize: '14px'
    }
  }, "Notifications"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '11px',
      padding: '2px 8px',
      borderRadius: '10px',
      background: '#FFF1F0',
      color: '#C93A34',
      fontWeight: 600
    }
  }, unread, " unread")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: '320px',
      overflowY: 'auto'
    }
  }, notifs.map(n => {
    const Icon = Icons[n.icon] || Icons.Bell;
    return /*#__PURE__*/React.createElement("div", {
      key: n.id,
      style: {
        display: 'flex',
        alignItems: 'flex-start',
        gap: '10px',
        padding: '11px 16px',
        borderBottom: '1px solid #EDEDF6',
        background: n.unread ? '#FAFAFF' : 'transparent',
        cursor: 'pointer',
        transition: 'background 0.1s'
      },
      onMouseEnter: e => e.currentTarget.style.background = '#F5F4FF',
      onMouseLeave: e => e.currentTarget.style.background = n.unread ? '#FAFAFF' : 'transparent'
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: '32px',
        height: '32px',
        borderRadius: '8px',
        background: n.color + '14',
        border: `1px solid ${n.color}22`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      size: 14,
      color: n.color
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: '12px',
        color: '#1A1828',
        lineHeight: 1.4
      }
    }, n.text), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: '11px',
        color: '#9C99B5',
        marginTop: '3px'
      }
    }, n.time)), n.unread && /*#__PURE__*/React.createElement("div", {
      style: {
        width: '7px',
        height: '7px',
        borderRadius: '50%',
        background: '#7C6AF7',
        flexShrink: 0,
        marginTop: '4px'
      }
    }));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 16px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setNotifs(prev => prev.map(n => ({
      ...n,
      unread: false
    }))),
    style: {
      width: '100%',
      padding: '8px',
      background: '#F5F4FF',
      border: '1px solid #E4E2F4',
      borderRadius: '8px',
      color: '#6E6B85',
      fontSize: '12px',
      cursor: 'pointer',
      fontFamily: "'DM Sans',sans-serif"
    }
  }, "Mark all as read")))), /*#__PURE__*/React.createElement("div", {
    ref: avatarRef,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => {
      setAvatarOpen(!avatarOpen);
      setNotifOpen(false);
    },
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      cursor: 'pointer',
      padding: '4px 8px',
      borderRadius: '8px',
      border: `1px solid ${avatarOpen ? '#E4E2F4' : 'transparent'}`,
      background: avatarOpen ? '#F5F4FF' : 'transparent',
      transition: 'all 0.15s'
    },
    onMouseEnter: e => {
      e.currentTarget.style.borderColor = '#E4E2F4';
      e.currentTarget.style.background = '#F5F4FF';
    },
    onMouseLeave: e => {
      if (!avatarOpen) {
        e.currentTarget.style.borderColor = 'transparent';
        e.currentTarget.style.background = 'transparent';
      }
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '34px',
      height: '34px',
      borderRadius: '50%',
      background: 'linear-gradient(135deg,#7C6AF7,#4FACFE)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '13px',
      fontWeight: 700,
      color: '#fff'
    }
  }, "N"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '12px',
      fontWeight: 600,
      color: '#1A1828',
      lineHeight: 1.2
    }
  }, "Noman"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '11px',
      color: '#9C99B5'
    }
  }, "Admin")), /*#__PURE__*/React.createElement(Icons.ChevronDown, {
    size: 12,
    color: "#9C99B5"
  })), avatarOpen && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'calc(100% + 8px)',
      right: 0,
      width: '220px',
      background: '#fff',
      border: '1px solid #E4E2F4',
      borderRadius: '12px',
      boxShadow: '0 8px 32px rgba(28,24,60,0.12)',
      zIndex: 300,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px',
      background: '#FAFAFF',
      borderBottom: '1px solid #EDEDF6',
      display: 'flex',
      alignItems: 'center',
      gap: '10px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '38px',
      height: '38px',
      borderRadius: '50%',
      background: 'linear-gradient(135deg,#7C6AF7,#4FACFE)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '14px',
      fontWeight: 700,
      color: '#fff'
    }
  }, "N"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '13px',
      fontWeight: 600,
      color: '#1A1828'
    }
  }, "Noman Ibrahim"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '11px',
      color: '#9C99B5'
    }
  }, "nomaan.ibrahim0336"))), [{
    icon: 'UserIcon',
    label: 'Profile Settings'
  }, {
    icon: 'Store',
    label: 'My Store'
  }, {
    icon: 'HelpCircle',
    label: 'Help & Support'
  }, {
    icon: 'Keyboard',
    label: 'Shortcuts'
  }].map(item => {
    const Icon = Icons[item.icon];
    return /*#__PURE__*/React.createElement("button", {
      key: item.label,
      onClick: () => setAvatarOpen(false),
      style: {
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        padding: '9px 14px',
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        color: '#6E6B85',
        fontSize: '13px',
        textAlign: 'left',
        fontFamily: "'DM Sans',sans-serif",
        transition: 'background 0.1s'
      },
      onMouseEnter: e => e.currentTarget.style.background = '#F5F4FF',
      onMouseLeave: e => e.currentTarget.style.background = 'none'
    }, Icon && /*#__PURE__*/React.createElement(Icon, {
      size: 14
    }), " ", item.label);
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid #EDEDF6',
      margin: '4px 0'
    }
  }), /*#__PURE__*/React.createElement("button", {
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      padding: '9px 14px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: '#C93A34',
      fontSize: '13px',
      textAlign: 'left',
      fontFamily: "'DM Sans',sans-serif"
    },
    onMouseEnter: e => e.currentTarget.style.background = '#FFF1F0',
    onMouseLeave: e => e.currentTarget.style.background = 'none'
  }, /*#__PURE__*/React.createElement(Icons.LogOut, {
    size: 14
  }), " Sign Out")))));
}
window.CRMTopbar = Topbar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/crm/Topbar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/crm/data.js
try { (() => {
window.CRM_DATA = {
  revenueData: [{
    date: 'Nov 5',
    v: 18400
  }, {
    date: 'Nov 6',
    v: 22100
  }, {
    date: 'Nov 7',
    v: 19800
  }, {
    date: 'Nov 8',
    v: 25300
  }, {
    date: 'Nov 9',
    v: 21000
  }, {
    date: 'Nov 10',
    v: 28700
  }, {
    date: 'Nov 11',
    v: 31200
  }, {
    date: 'Nov 12',
    v: 26800
  }, {
    date: 'Nov 13',
    v: 29400
  }, {
    date: 'Nov 14',
    v: 33100
  }, {
    date: 'Nov 15',
    v: 27600
  }, {
    date: 'Nov 16',
    v: 35000
  }, {
    date: 'Nov 17',
    v: 32100
  }, {
    date: 'Nov 18',
    v: 29800
  }, {
    date: 'Nov 19',
    v: 38400
  }, {
    date: 'Nov 20',
    v: 42100
  }, {
    date: 'Nov 21',
    v: 36700
  }, {
    date: 'Nov 22',
    v: 40200
  }, {
    date: 'Nov 23',
    v: 44800
  }, {
    date: 'Nov 24',
    v: 38900
  }, {
    date: 'Nov 25',
    v: 51200
  }, {
    date: 'Nov 26',
    v: 47600
  }, {
    date: 'Nov 27',
    v: 43100
  }, {
    date: 'Nov 28',
    v: 56800
  }, {
    date: 'Nov 29',
    v: 49300
  }, {
    date: 'Nov 30',
    v: 52700
  }, {
    date: 'Dec 1',
    v: 61200
  }, {
    date: 'Dec 2',
    v: 58400
  }, {
    date: 'Dec 3',
    v: 64100
  }, {
    date: 'Dec 4',
    v: 71800
  }],
  ordersBySource: [{
    name: 'Shopify',
    value: 38,
    color: '#7C6AF7'
  }, {
    name: 'Instagram',
    value: 28,
    color: '#1DB87A'
  }, {
    name: 'WhatsApp',
    value: 21,
    color: '#3A8AE8'
  }, {
    name: 'Website',
    value: 10,
    color: '#F5A623'
  }, {
    name: 'Mobile App',
    value: 3,
    color: '#E2514A'
  }],
  orders: [{
    id: '#ORD-7841',
    customer: 'Aisha Malik',
    avatar: 'AM',
    city: 'Karachi',
    amount: 12500,
    payment: 'COD',
    status: 'Delivered',
    source: 'Instagram',
    date: '2024-12-04',
    courier: 'TCS',
    tracking: 'TCS-88291'
  }, {
    id: '#ORD-7840',
    customer: 'Bilal Ahmed',
    avatar: 'BA',
    city: 'Lahore',
    amount: 8900,
    payment: 'Card',
    status: 'Shipped',
    source: 'Shopify',
    date: '2024-12-04',
    courier: 'Leopard',
    tracking: 'LEP-44512'
  }, {
    id: '#ORD-7839',
    customer: 'Sara Khan',
    avatar: 'SK',
    city: 'Islamabad',
    amount: 19800,
    payment: 'Easypaisa',
    status: 'Processing',
    source: 'WhatsApp',
    date: '2024-12-03',
    courier: 'BlueEx',
    tracking: 'BEX-22987'
  }, {
    id: '#ORD-7838',
    customer: 'Usman Tariq',
    avatar: 'UT',
    city: 'Faisalabad',
    amount: 4200,
    payment: 'COD',
    status: 'Pending',
    source: 'Instagram',
    date: '2024-12-03',
    courier: null,
    tracking: null
  }, {
    id: '#ORD-7837',
    customer: 'Fatima Zahra',
    avatar: 'FZ',
    city: 'Karachi',
    amount: 6700,
    payment: 'Card',
    status: 'Shipped',
    source: 'Website',
    date: '2024-12-02',
    courier: 'TCS',
    tracking: 'TCS-88190'
  }, {
    id: '#ORD-7836',
    customer: 'Hassan Raza',
    avatar: 'HR',
    city: 'Rawalpindi',
    amount: 7500,
    payment: 'COD',
    status: 'Delivered',
    source: 'Shopify',
    date: '2024-12-02',
    courier: 'Leopard',
    tracking: 'LEP-44490'
  }, {
    id: '#ORD-7835',
    customer: 'Zainab Hussain',
    avatar: 'ZH',
    city: 'Lahore',
    amount: 11200,
    payment: 'JazzCash',
    status: 'Processing',
    source: 'Instagram',
    date: '2024-12-01',
    courier: null,
    tracking: null
  }, {
    id: '#ORD-7834',
    customer: 'Omar Farooq',
    avatar: 'OF',
    city: 'Multan',
    amount: 9800,
    payment: 'COD',
    status: 'Cancelled',
    source: 'WhatsApp',
    date: '2024-12-01',
    courier: null,
    tracking: null
  }, {
    id: '#ORD-7833',
    customer: 'Hina Baig',
    avatar: 'HB',
    city: 'Karachi',
    amount: 5400,
    payment: 'Card',
    status: 'Delivered',
    source: 'Mobile App',
    date: '2024-11-30',
    courier: 'BlueEx',
    tracking: 'BEX-22880'
  }, {
    id: '#ORD-7832',
    customer: 'Kamran Sheikh',
    avatar: 'KS',
    city: 'Peshawar',
    amount: 16700,
    payment: 'COD',
    status: 'Shipped',
    source: 'Shopify',
    date: '2024-11-30',
    courier: 'TCS',
    tracking: 'TCS-88100'
  }],
  customers: [{
    id: 'C001',
    name: 'Aisha Malik',
    avatar: 'AM',
    phone: '+92 300 1234567',
    city: 'Karachi',
    orders: 12,
    spent: 94200,
    lastOrder: '2024-12-04',
    source: 'Instagram',
    status: 'VIP'
  }, {
    id: 'C002',
    name: 'Bilal Ahmed',
    avatar: 'BA',
    phone: '+92 321 9876543',
    city: 'Lahore',
    orders: 8,
    spent: 67800,
    lastOrder: '2024-12-04',
    source: 'Shopify',
    status: 'Regular'
  }, {
    id: 'C003',
    name: 'Sara Khan',
    avatar: 'SK',
    phone: '+92 333 5556677',
    city: 'Islamabad',
    orders: 5,
    spent: 41200,
    lastOrder: '2024-12-03',
    source: 'WhatsApp',
    status: 'Regular'
  }, {
    id: 'C004',
    name: 'Usman Tariq',
    avatar: 'UT',
    phone: '+92 345 7778899',
    city: 'Faisalabad',
    orders: 3,
    spent: 18900,
    lastOrder: '2024-12-03',
    source: 'Instagram',
    status: 'New'
  }, {
    id: 'C005',
    name: 'Fatima Zahra',
    avatar: 'FZ',
    phone: '+92 312 3334445',
    city: 'Karachi',
    orders: 15,
    spent: 128400,
    lastOrder: '2024-12-02',
    source: 'Website',
    status: 'VIP'
  }, {
    id: 'C006',
    name: 'Hassan Raza',
    avatar: 'HR',
    phone: '+92 300 9998887',
    city: 'Rawalpindi',
    orders: 7,
    spent: 52100,
    lastOrder: '2024-12-02',
    source: 'Shopify',
    status: 'Regular'
  }, {
    id: 'C007',
    name: 'Zainab Hussain',
    avatar: 'ZH',
    phone: '+92 321 2221110',
    city: 'Lahore',
    orders: 9,
    spent: 78600,
    lastOrder: '2024-12-01',
    source: 'Instagram',
    status: 'Regular'
  }, {
    id: 'C008',
    name: 'Omar Farooq',
    avatar: 'OF',
    phone: '+92 333 4445556',
    city: 'Multan',
    orders: 2,
    spent: 14200,
    lastOrder: '2024-12-01',
    source: 'WhatsApp',
    status: 'New'
  }, {
    id: 'C009',
    name: 'Hina Baig',
    avatar: 'HB',
    phone: '+92 345 6667778',
    city: 'Karachi',
    orders: 11,
    spent: 89300,
    lastOrder: '2024-11-30',
    source: 'Mobile App',
    status: 'VIP'
  }, {
    id: 'C010',
    name: 'Kamran Sheikh',
    avatar: 'KS',
    phone: '+92 312 8889990',
    city: 'Peshawar',
    orders: 6,
    spent: 44800,
    lastOrder: '2024-11-30',
    source: 'Shopify',
    status: 'Regular'
  }],
  conversations: [{
    id: 'c1',
    customer: 'Aisha Malik',
    avatar: 'AM',
    channel: 'WhatsApp',
    lastMsg: 'When will my order be delivered?',
    time: '2 min ago',
    unread: 2,
    status: 'Open',
    messages: [{
      from: 'customer',
      text: 'Hi, I placed an order yesterday #ORD-7841',
      time: '10:30 AM'
    }, {
      from: 'bot',
      text: 'Hello Aisha! Your order #ORD-7841 was shipped via TCS (TCS-88291).',
      time: '10:30 AM'
    }, {
      from: 'customer',
      text: 'When will my order be delivered?',
      time: '10:32 AM'
    }]
  }, {
    id: 'c2',
    customer: 'Sara Khan',
    avatar: 'SK',
    channel: 'Instagram',
    lastMsg: 'Do you have this in size M?',
    time: '15 min ago',
    unread: 1,
    status: 'Open',
    messages: [{
      from: 'customer',
      text: 'Hi! I saw your post about the Zara dresses',
      time: '9:45 AM'
    }, {
      from: 'bot',
      text: 'Hello Sara! Yes, we have the full Zara collection. Which style are you interested in?',
      time: '9:45 AM'
    }, {
      from: 'customer',
      text: 'Do you have this in size M?',
      time: '9:50 AM'
    }]
  }, {
    id: 'c3',
    customer: 'Bilal Ahmed',
    avatar: 'BA',
    channel: 'WhatsApp',
    lastMsg: 'Thanks! Order confirmed.',
    time: '1 hr ago',
    unread: 0,
    status: 'Closed',
    messages: [{
      from: 'customer',
      text: 'I want to order the Samsung Galaxy Buds',
      time: '8:00 AM'
    }, {
      from: 'bot',
      text: 'Great choice! PKR 8,900. Shall I place the order?',
      time: '8:00 AM'
    }, {
      from: 'customer',
      text: 'Yes please, COD to Lahore',
      time: '8:02 AM'
    }, {
      from: 'agent',
      text: 'Order placed! #ORD-7840 confirmed. Expected delivery in 3-4 days.',
      time: '8:05 AM'
    }, {
      from: 'customer',
      text: 'Thanks! Order confirmed.',
      time: '8:06 AM'
    }]
  }, {
    id: 'c4',
    customer: 'Usman Tariq',
    avatar: 'UT',
    channel: 'Instagram',
    lastMsg: 'What are the payment options?',
    time: '3 hr ago',
    unread: 3,
    status: 'Open',
    messages: [{
      from: 'customer',
      text: 'What are the payment options?',
      time: '6:15 AM'
    }]
  }, {
    id: 'c5',
    customer: 'Fatima Zahra',
    avatar: 'FZ',
    channel: 'WhatsApp',
    lastMsg: 'Can I get a discount on bulk order?',
    time: '2 hr ago',
    unread: 0,
    status: 'Open',
    messages: [{
      from: 'customer',
      text: 'I want to buy 5 yoga mats for my studio',
      time: '7:30 AM'
    }, {
      from: 'bot',
      text: 'We do offer bulk discounts on orders of 5+!',
      time: '7:30 AM'
    }, {
      from: 'customer',
      text: 'Can I get a discount on bulk order?',
      time: '7:35 AM'
    }]
  }, {
    id: 'c6',
    customer: 'Kamran Sheikh',
    avatar: 'KS',
    channel: 'Telegram',
    lastMsg: 'Is the cricket bat still available?',
    time: '5 min ago',
    unread: 1,
    status: 'Open',
    messages: [{
      from: 'customer',
      text: 'Hey! Is the cricket bat still available?',
      time: '10:55 AM'
    }, {
      from: 'bot',
      text: 'Hi Kamran! Yes, Kashmir Willow Cricket Bat is in stock at PKR 8,500.',
      time: '10:55 AM'
    }, {
      from: 'customer',
      text: 'Is the cricket bat still available?',
      time: '10:58 AM'
    }]
  }],
  activityFeed: [{
    id: 1,
    type: 'order',
    text: 'New order #ORD-7841 from Aisha Malik',
    time: '2 min ago',
    color: '#7C6AF7'
  }, {
    id: 2,
    type: 'message',
    text: 'Sara Khan sent a message on Instagram',
    time: '8 min ago',
    color: '#3A8AE8'
  }, {
    id: 3,
    type: 'order',
    text: 'Order #ORD-7840 shipped via Leopard',
    time: '22 min ago',
    color: '#F5A623'
  }, {
    id: 4,
    type: 'customer',
    text: 'New customer signed up: Usman Tariq',
    time: '45 min ago',
    color: '#1DB87A'
  }, {
    id: 5,
    type: 'payment',
    text: 'Payment received PKR 19,800 from Sara Khan',
    time: '1 hr ago',
    color: '#1DB87A'
  }, {
    id: 6,
    type: 'order',
    text: 'Order #ORD-7839 processing started',
    time: '1.5 hr ago',
    color: '#7C6AF7'
  }, {
    id: 7,
    type: 'message',
    text: 'Fatima Zahra asking about bulk discount',
    time: '2 hr ago',
    color: '#3A8AE8'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/crm/data.js", error: String((e && e.message) || e) }); }

})();

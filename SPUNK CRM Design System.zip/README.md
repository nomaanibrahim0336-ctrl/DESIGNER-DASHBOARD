# SPUNK CRM — Design System

> Design system for the SPUNK e-commerce CRM platform. Use this to build pixel-accurate UI recreations, prototypes, and brand assets.

---

## Source Repositories

| Repo | Description | URL |
|------|-------------|-----|
| `nomaanibrahim0336-ctrl/CRM-` | Main React/Vite CRM frontend + Node.js backend | https://github.com/nomaanibrahim0336-ctrl/CRM- |
| `nomaanibrahim0336-ctrl/Marketing` | Next.js marketing platform (alt product) | https://github.com/nomaanibrahim0336-ctrl/Marketing |
| `nomaanibrahim0336-ctrl/DESIGNER-DASHBOARD` | Design system repo (this project) | https://github.com/nomaanibrahim0336-ctrl/DESIGNER-DASHBOARD |

> These repos are private. Access requires GitHub App authorization on the `nomaanibrahim0336-ctrl` account.

---

## Product Overview

**SPUNK** builds e-commerce operations software for Pakistani online sellers. The flagship product is a **CRM dashboard** (React + Vite + Tailwind) targeting D2C sellers who manage orders across Instagram, WhatsApp, Shopify, and their own websites.

### Products

**1. CRM (Primary)**
- React 18 + Vite + Tailwind CSS
- Font: DM Sans + JetBrains Mono
- Accent: `#7C6AF7` (purple)
- Pages: Dashboard, Orders, Customers, DM Conversations, Products, Inventory, Analytics, Financials, Courier, Integrations, Settings
- Source: `nomaanibrahim0336-ctrl/CRM-` → `src/`

**2. Marketing Platform (Secondary)**
- Next.js 14 + Tailwind CSS
- Font: Inter + JetBrains Mono
- Accent: `#6366f1` (indigo)
- Pages: Dashboard, Customers, Orders, Inbox, WhatsApp, Meta, Courier, Finance, Products, Settings, Admin
- Source: `nomaanibrahim0336-ctrl/Marketing` → `frontend/`

Both products share the same **dark-mode dashboard** visual language, differing mainly in accent color and font choice.

---

## Content Fundamentals

### Tone
- **Professional, direct, data-first.** No marketing fluff; every word earns its place.
- B2B ops tool — the user is a store owner or team member managing hundreds of daily orders.
- No humor, no exclamation marks in UI labels (save those for success toasts).

### Voice
- **Second person ("you")** implied by structure; never "I" from the system.
- Commands and labels in **sentence case**: "Add product", "Export CSV", "Mark all read".
- Section group headers are **ALL CAPS**: `OVERVIEW`, `SALES`, `CATALOG`, `PERFORMANCE`, `LOGISTICS`.
- Table column headers are **ALL CAPS** with letter-spacing: `ORDER ID`, `CUSTOMER`, `STATUS`.

### Copy Examples
- Page subtitles: *"Welcome back, here's what's happening today"* — warm but brief.
- Stat card labels: *"Total Orders"*, *"Revenue"*, *"Pending Shipment"* — noun phrases, title case.
- Notification copy: *"New order #ORD-7841 from Aisha Malik"* — event + identifier + actor.
- Toast messages: Short verb phrases: *"Logs exported"*, *"Synced"*, *"Changes saved"*.

### Locale
- Currency: **PKR** (Pakistani Rupees), formatted as `PKR 19,800` — no ₨ symbol.
- Phone numbers: **+92** format, e.g. `+92 300 1234567`.
- Cities: Karachi, Lahore, Islamabad, Faisalabad, Rawalpindi, Peshawar, Multan.
- Local couriers: TCS, Leopard, BlueEx, PostEx.
- Local payment methods: COD, Easypaisa, JazzCash, Card.
- No emoji in UI. Emoji appear only in customer-generated messages (conversations).

### Data Formatting
- Order IDs: `#ORD-7841` (always uppercase, monospace font).
- SKUs: `NK-AM270-BLK` (uppercase, monospace).
- Percentages: `+8.2%`, `-3%` with `+` for positive changes.
- Timestamps: `2 min ago`, `1 hr ago`, `2024-12-04` (ISO for tables).

---

## Visual Foundations

### Color System

**Backgrounds (darkest → lightest)**
| Token | Value | Usage |
|-------|-------|-------|
| `--bg-base` | `#0D0D0F` | App root, page background |
| `--bg-surface` | `#141418` | Sidebar, topbar, cards |
| `--bg-elevated` | `#1C1C22` | Dropdowns, modals, table headers |
| `--bg-hover` | `#23232B` | Row hover, item hover |

**Borders**
| Token | Value | Usage |
|-------|-------|-------|
| `--border` | `#2A2A35` | Cards, inputs, dropdowns |
| `--border-subtle` | `#1F1F28` | Table row dividers, section separators |

**Text**
| Token | Value | Usage |
|-------|-------|-------|
| `--text-primary` | `#F0EFF6` | Headings, values, primary content |
| `--text-secondary` | `#8A8A9E` | Labels, descriptions, nav items |
| `--text-tertiary` | `#55556A` | Timestamps, placeholders, section labels |

**Accent**
| Token | Value | Usage |
|-------|-------|-------|
| `--accent` | `#7C6AF7` | CTA buttons, active nav, order IDs |
| `--accent-hover` | `#9180FF` | Accent hover state |
| `--accent-muted` | `#2A2550` | Active nav bg, accent tint backgrounds |

**Status Colors** (each has a vivid + muted pair for icon bg + text)
| Status | Vivid | Muted | Uses |
|--------|-------|-------|------|
| Green | `#1DB87A` | `#0F3D2A` | Delivered, Active, Revenue |
| Amber | `#F5A623` | `#3D2D0A` | Pending, Low Stock, Warning |
| Red | `#E2514A` | `#3D1414` | Cancelled, Error, Out of Stock |
| Blue | `#3A8AE8` | `#0D2A4A` | Shipped, New, Info |

### Typography

**Primary: DM Sans** (Google Fonts)
- Weights used: 300, 400, 500, 600, 700
- Variable font: opsz 9–40
- Applied to: all body text, buttons, labels, headings
- Base size: **13px** (all body copy)

**Monospace: JetBrains Mono** (Google Fonts)
- Weights used: 400, 500
- Applied to: order IDs, SKUs, timestamps in tables, code, keyboard shortcut labels

**Type Scale**
| Role | Size | Weight | Color |
|------|------|--------|-------|
| Page title (h1) | 20px | 700 | primary |
| Card heading (h2) | 14px | 600 | primary |
| Section label | 10px | 700 | tertiary, UPPERCASE, 0.08em spacing |
| Table header | 11px | 600 | tertiary, UPPERCASE, 0.05em spacing |
| Body / default | 13px | 400–500 | primary / secondary |
| Caption / time | 11–12px | 400 | tertiary / secondary |
| Stat value | 26px | 700 | primary |
| Badge text | 11px | 600 | status color |
| Mono (IDs, SKUs) | 12px | 400 | accent |

### Backgrounds & Surfaces
- **No full-bleed images.** All backgrounds are solid dark colors.
- **No gradients** in backgrounds — flat surfaces only.
- Gradient exception: Logo mark only — `linear-gradient(135deg, #7C6AF7, #9180FF)`.
- Avatar gradient: `linear-gradient(135deg, #7C6AF7, #3A8AE8)` (purple → blue).
- No hand-drawn illustrations, no repeating patterns, no textures.

### Cards
- Background: `#141418` (--bg-surface)
- Border: `1px solid #2A2A35`
- Border-radius: **12px** (--radius-xl)
- Padding: **20px** (--space-5)
- **No drop shadow on cards** — border-only approach for cleanliness
- Card headers (inside cards): smaller padding `16px 20px`, border-bottom `1px solid #1F1F28`

### Elevation & Shadows
- Cards: no shadow (border only)
- Dropdowns / notification panels: `0 8px 32px rgba(0,0,0,0.5)`
- Modals / search overlay: `0 20px 60px rgba(0,0,0,0.7)`
- Modal backdrop: `rgba(0,0,0,0.7)` full-screen

### Hover & Press States
- Row hover: bg → `#23232B`, `transition: background 0.1s`
- Button hover: background lightens by one step (no opacity trick)
- Nav item hover: bg → `#23232B`, color → `#F0EFF6`
- Card border hover (integration cards): border-color → icon's brand color at `44%` opacity
- Press/active: `active:scale-95` in Marketing; not used in CRM explicitly
- Transition speed: `0.1s ease` for hover bg, `0.15s ease` for button colors, `0.2s ease` for layout (sidebar)

### Borders
- Default border: `1px solid #2A2A35`
- Subtle divider: `1px solid #1F1F28` (inside surfaces)
- Active nav: `3px solid #7C6AF7` left border
- Input focus: ring-style (blur via `focus:ring-2 focus:ring-indigo-500/50` in Marketing)
- No right/top/bottom accent borders on cards

### Animations
- No decorative animations
- Sidebar collapse: `width 0.2s ease, min-width 0.2s ease`
- Fade-in dropdown: instant (no animation, just z-index)
- Sync icon spin: `@keyframes spin 1s linear infinite` (loading only)
- Marketing has: `fadeIn 0.2s ease-in-out`, `slideUp 0.3s ease-out`

### Corner Radii
| Token | Value | Usage |
|-------|-------|-------|
| `--radius-xs` | 3px | Scrollbar thumb |
| `--radius-sm` | 4px | kbd, tag background |
| `--radius-md` | 6px | Collapse toggle, filter tabs |
| `--radius-lg` | 8px | Buttons, inputs, notification items, icon boxes |
| `--radius-xl` | 12px | Cards, modals, panels, nav items (collapsed) |
| `--radius-2xl` | 14px | Search modal, large modals |
| `--radius-full` | 999px | Status badges (pill) |

### Layout
- **Fixed sidebar**: 240px wide (collapsed: 64px); `position: fixed` equivalent via flex
- **Fixed topbar**: 60px height; `position: sticky; top: 0; z-index: 100`
- **Main content**: scrollable, `padding: 28px`
- Grid: 4-column for stat cards, 3-column for integrations, 2-column for chart rows
- Gap: **16px** between grid cells

### Imagery
- **No photography in the UI.** All visual data is numbers, icons, and status indicators.
- Avatar initials only (never photos) — gradient circle with 2-letter monogram.
- Color vibe: near-monochrome dark with purple/green/amber accents. No warm imagery.

### Use of Transparency & Blur
- Icon backgrounds: `color + '22'` (13% opacity) for bg, `color + '33'` (20%) for border
- Unread notification rows: `#1C1C2233` (very subtle tint)
- Backdrop blur: used in Marketing `card` class (`backdrop-blur-sm`) — not in CRM
- No frosted glass in CRM

---

## Iconography

SPUNK CRM uses **Lucide React** icons exclusively throughout all UI.

### Icon Style
- **Stroke icons** (not filled), consistent 1.5–2px stroke weight (Lucide default)
- Typical sizes: `14px` for small UI (nav, table), `16–18px` for card icons, `22px` for integration icons
- Never inline SVG hand-rolled icons — always Lucide components

### Icon Usage Patterns
1. **Navigation icons**: 16px, `#8A8A9E` (inactive), `#7C6AF7` (active)
2. **Stat card icons**: 18px inside a 36×36 icon box (color at 22% bg, color for stroke)
3. **Integration card icons**: 22px inside a 44×44 icon box
4. **Topbar icons**: 16px, secondary color
5. **Activity feed icons**: 8px inside a 16×16 circle indicator
6. **Table action icons**: 14px, tertiary color

### Icon Backgrounds (Icon Box Pattern)
```css
width: 36px; height: 36px; border-radius: 8px;
background: {color}22;  /* 13% opacity */
border: 1px solid {color}33;  /* 20% opacity */
```
Color matches the icon's semantic role (accent, green, amber, red, blue).

### CDN Usage
```html
<!-- In React/Babel projects -->
<script src="https://unpkg.com/lucide-react@0.344.0/dist/umd/lucide-react.min.js"></script>
<!-- Access: const { LayoutDashboard, ShoppingCart } = window.LucideReact; -->
```

### Icons per Section
| Section | Icons Used |
|---------|-----------|
| Sidebar — Overview | `LayoutDashboard` |
| Sidebar — Sales | `ShoppingCart`, `Users`, `MessageSquare` |
| Sidebar — Catalog | `Package`, `Layers` |
| Sidebar — Performance | `BarChart2`, `DollarSign` |
| Sidebar — Logistics | `Truck` |
| Sidebar — Integrations | `Zap` |
| Sidebar — Settings | `Settings` |
| Topbar | `Search`, `Bell`, `ChevronDown` |
| Dashboard | `ShoppingCart`, `DollarSign`, `Users`, `Clock` |
| Status badges | `TrendingUp`, `TrendingDown` |
| Notifications | `ShoppingBag`, `MessageSquare`, `Truck`, `AlertCircle`, `CreditCard` |

---

## File Index

```
/
├── README.md                        ← This file
├── SKILL.md                         ← Agent skill definition
├── colors_and_type.css              ← All design tokens as CSS variables
│
├── preview/                         ← Design system card previews
│   ├── colors-backgrounds.html      Colors: Background layers
│   ├── colors-accent.html           Colors: Accent purple scale
│   ├── colors-status.html           Colors: Status color pairs
│   ├── colors-text.html             Colors: Text hierarchy
│   ├── type-scale.html              Type: Heading & body scale
│   ├── type-mono.html               Type: JetBrains Mono specimens
│   ├── spacing-tokens.html          Spacing: Space scale tokens
│   ├── spacing-radii.html           Spacing: Border radii + shadows
│   ├── components-buttons.html      Components: Button variants
│   ├── components-badges.html       Components: Badge/status variants
│   ├── components-statcard.html     Components: Stat cards
│   ├── components-inputs.html       Components: Input fields
│   ├── components-sidebar.html      Components: Sidebar navigation
│   ├── components-topbar.html       Components: Topbar
│   └── brand-logo.html              Brand: Logo mark + wordmark
│
└── ui_kits/
    └── crm/                         ← CRM Dashboard UI Kit
        ├── README.md
        ├── index.html               ← Interactive prototype entry point
        ├── data.js                  ← Mock data
        ├── Components.jsx           ← Shared UI components
        ├── Sidebar.jsx              ← Sidebar navigation
        ├── Topbar.jsx               ← Top navigation bar
        ├── Dashboard.jsx            ← Dashboard page
        ├── Orders.jsx               ← Orders page
        ├── Customers.jsx            ← Customers page
        ├── Conversations.jsx        ← DM Conversations page
        └── App.jsx                  ← Root app component
```
